<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Travel Agency :: Best Agency</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

   <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
   <script>
      $(document).ready(function(){
          $(".scroll-top").click(function() {
              $("html, body").animate({ 
                  scrollTop: 0 
              }, "slow");
              return false;
          });
      });
   </script>

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo"><img src="images/logo1.png"></a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php" class="active">package</a>
      <a href="book.php">book</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<div class="heading" style="background:url(images/header-bg-2.png) no-repeat">
   <h1>packages</h1>
</div>

<!-- packages section starts  -->

<section class="packages">

   <h1 class="heading-title">top destinations</h1>

   <div class="box-container">
   <div class="box">
         <div class="image">
            <img src="images/img-12.jpg" alt="">
         </div>
         <div class="content">
            <h3>Japan Tour Packages</h3>
            <p>Enjoy the Emirates with unforgettable fun with our Japan top selling packages!</p>
            <h2>BDT 11,900</h2>
            <div class="mid_wrap">
        <h2 class="headtl" style="text-transform: capitalize;">Japan Tour Packages</h2>
        <div class="abttxt">
            <p><span style="color: #263238; font-family: Roboto, sans-serif; font-size: 13px;">Get ready to explore the history of Japan with your family. This small Asian country has lot to offer to all the travelers. Japan is a country with fascinating history, attractive sightseeing places, spectacular cathedrals, and amazing Buddhist temples. Explore the best places and indulge in cultural activities in Japan by booking a holiday package to this wonderful place. </span></p>

        </div>
        <!-- ngIf: PackList.isFilter -->

        <div class="rightList">
            <style>
                .no-serch {
                    padding: 20px;
                    border: 1px solid #d6d6d6;
                    background: #fff;
                    width: 30%;
                    display: flex;
                    align-items: center;
                    flex-direction: column;
                    border-radius: 8px;
                    margin: 40px auto;
                    box-shadow: 0px 0px 8px 0px rgba(50,50,50,0.20);
                }

                .txtcnt {
                    margin-top: 15px;
                    font-weight: 600;
                }

                .ifslrTTC .inclsn, .inclsn .ifslrTTC, .ifslrTTC .inclsn {
                    display: none;
                }

                .ifslrTTC {
                    min-height: 340px;
                }

                    .ifslrTTC .pricesec {
                        padding: 0px;
                        display: none;
                    }
            </style>
            <div class="no-serch" id="no-serch-div" style="display:none">
                <img src="/holidays/Content/customize/img/no-content.png" width="80">
                <div class="txtcnt">No Package Available </div>
            </div>
            <div class="listpnl">
                
                <!-- ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638115395361909190/SightSeeing/SightSeeingC3mt6i.jpg" src="https://media.easemytrip.com/media/Deal/DL638115395361909190/SightSeeing/SightSeeingC3mt6i.jpg"></div>
                        
                        <p class="tnight ng-binding">9 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Memorable Japan</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Tokyo | 1N Hiroshima | 2N Kyoto | 2N Osaka</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638115395361909190" type="radio" id="htl_01DL638115395361909190Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638115395361909190Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">HND</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">HND</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638115395361909190" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 267604
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹252470
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638115395361909190" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../memorable-japan-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../memorable-japan-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">45834</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638119916977848791/SightSeeing/SightSeeingqnpnlb.jpg" src="https://media.easemytrip.com/media/Deal/DL638119916977848791/SightSeeing/SightSeeingqnpnlb.jpg"></div>
                        
                        <p class="tnight ng-binding">7 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Essence Of Japan</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">02N Tokyo/ 01N Hakone/ 02N Kyoto/ 02N Osaka</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638119916977848791">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 119699
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638119916977848791" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../essence-of-japan-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../essence-of-japan-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">20936</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638291598162498656/Attraction/Attraction8Dy2SA.jpg" src="https://media.easemytrip.com/media/Deal/DL638291598162498656/Attraction/Attraction8Dy2SA.jpg"></div>
                        
                        <p class="tnight ng-binding">14 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Exciting Japan and South Korea</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">1N Seoul | 1N Sokcho | 1N Daegu | 1N Gyeongju | 2N Seoul | 2N Tokyo | 1N Hamamatsu | 3N Osaka | 1N Hiroshima| 1N Osaka</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 398990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638291598162498656">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 315199
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638291598162498656" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../exciting-japan-and-south-korea-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../exciting-japan-and-south-korea-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">53846</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638587270156738249/SightSeeing/SightSeeingQr8j0P.jpg" src="https://media.easemytrip.com/media/Deal/DL638587270156738249/SightSeeing/SightSeeingQr8j0P.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Discover the Wonders of Japan</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Tokyo | 3N Osaka</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 263890
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638587270156738249">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 163890
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638587270156738249" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../discover-the-wonders-of-japan-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../discover-the-wonders-of-japan-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">28375</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638587919370441295/SightSeeing/SightSeeingjWGQXc.jpg" src="https://media.easemytrip.com/media/Deal/DL638587919370441295/SightSeeing/SightSeeingjWGQXc.jpg"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Explore the Best of Japan</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">03N Tokyo- 02 Kyoto</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 252090
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638587919370441295">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 152090
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638587919370441295" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../explore-the-best-of-japan-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../explore-the-best-of-japan-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">26389</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638587973173030383/SightSeeing/SightSeeingEaGTBy.jpg" src="https://media.easemytrip.com/media/Deal/DL638587973173030383/SightSeeing/SightSeeingEaGTBy.jpg"></div>
                        
                        <p class="tnight ng-binding">7 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Discover the Essence of Japan</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">03N Tokyo - 04N Osaka</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 444190
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638587973173030383">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 344190
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638587973173030383" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../discover-the-essence-of-japan-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../discover-the-essence-of-japan-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">58726</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638588033201567801/SightSeeing/SightSeeingvccjUM.jpg" src="https://media.easemytrip.com/media/Deal/DL638588033201567801/SightSeeing/SightSeeingvccjUM.jpg"></div>
                        
                        <p class="tnight ng-binding">9 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Experience the Essence of Japan</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Tokyo | 3N Kyoto | 2N Osaka</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 339490
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638588033201567801">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 229490
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638588033201567801" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../experience-the-essence-of-japan-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../experience-the-essence-of-japan-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">39418</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638590514691916101/SightSeeing/SightSeeingzBLlDg.jpg" src="https://media.easemytrip.com/media/Deal/DL638590514691916101/SightSeeing/SightSeeingzBLlDg.jpg"></div>
                        
                        <p class="tnight ng-binding">11 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Discover the Heart of Japan</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Tokyo| 1N Hakone | 3N Kyoto | 4N Osaka</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 408190
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638590514691916101">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 308190
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638590514691916101" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../discover-the-heart-of-japan-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../discover-the-heart-of-japan-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">52666</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/a5dfahov/contiki-japan-in-a-week.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/a5dfahov/contiki-japan-in-a-week.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">7 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Japan in a Week</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Social travel for 18-35 yrs ONLY</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535094800061" type="radio" id="htl_01TTC638611535094800061Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535094800061Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535094800061">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 143243
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535094800061" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-japan-in-a-week-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-japan-in-a-week-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">24899</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/2499/majestic-japan-luxury-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/2499/majestic-japan-luxury-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">10 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Majestic Japan</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535152553671" type="radio" id="htl_01TTC638611535152553671Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535152553671Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535152553671">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 751478
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535152553671" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-majestic-japan-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-majestic-japan-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">127288</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/14668/splendors-japan-hiroshima-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/14668/splendors-japan-hiroshima-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">8 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Splendours of Japan</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Tour differently</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535181909877" type="radio" id="htl_01TTC638611535181909877Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535181909877Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535181909877">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 327943
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535181909877" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-splendours-of-japan-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-splendours-of-japan-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">55991</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/v3ineh1m/contiki-asia-japan-unrivalled.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/v3ineh1m/contiki-asia-japan-unrivalled.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">12 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Japan Unrivalled</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Social travel for 18-35 yrs ONLY</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535087835148" type="radio" id="htl_01TTC638611535087835148Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535087835148Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535087835148">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 277753
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535087835148" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-japan-unrivalled-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-japan-unrivalled-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">47542</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  -->




            </div>
        </div>


    </div>
            <a href="book.php" class="btn">book now</a>
         </div>
    </div>
   

      
</section>

<!-- packages section ends -->
      <!-- footer section starts  -->

<section class="footer">
   <div class="box-container">
      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>
      <div class="box">
         <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
      </div>
      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +880-1517-089144 </a>
         <a href="#"> <i class="fas fa-phone"></i> +111-2222-333333 </a>
         <a href="#"> <i class="fas fa-envelope"></i> vishalbca@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Raval, Devbhumi dwarka 361325  </a>
      </div>
      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
      </div>
   </div>
   <div class="credit"> designed by <span>mr. Vishal Vaghela</span> | all rights reserved! </div>
</section>

<!-- footer section ends -->
<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>