<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Travel Agency :: Best Agency</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

   <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
   <script>
      $(document).ready(function(){
          $(".scroll-top").click(function() {
              $("html, body").animate({ 
                  scrollTop: 0 
              }, "slow");
              return false;
          });
      });
   </script>

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo"><img src="images/logo1.png"></a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php" class="active">package</a>
      <a href="book.php">book</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<div class="heading" style="background:url(images/header-bg-2.png) no-repeat">
   <h1>packages</h1>
</div>

<!-- packages section starts  -->

<section class="packages">

   <h1 class="heading-title">top destinations</h1>

   <div class="box-container">

   <div class="box">
         <div class="image">
            <img src="images/img-2.jpg" alt="">
         </div>
         <div class="content">
            <h3>Delhi Tour Packages</h3>
            <p>Enjoy the Emirates with unforgettable fun with our Delhi top selling packages!</p>
            <h2>BDT 9,900</h2>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>
      <div class="col-md-12">
            <h2 class="title-decoration-lines-bottom heading-4">Delhi Tourism</h2>
            <p class="text-justify">
              Delhi, the capital of India, is a vibrant metropolis that encapsulates the essence of the nation. With a rich historical legacy spanning several centuries, <strong>Delhi Tour</strong> offers magnificent landmarks like the Red Fort, Qutub Minar, and Humayun's Tomb. The city's diverse culture is reflected in its bustling markets, mouthwatering street food, and religious sites such as Jama Masjid and Lotus Temple. Delhi seamlessly blends the old and the new, with modern infrastructure, luxury hotels, and upscale shopping malls coexisting alongside ancient bazaars and narrow lanes of Old Delhi. Delhi is a melting pot of traditions, flavors, and experiences that leave visitors captivated.
            </p>
            <p>
              The city offers a plethora of experiences and attractions, making it a must-visit destination for history enthusiasts, culture lovers, foodies, and anyone seeking to explore the heritage. We got covered a bundle of <strong>Delhi tour packages</strong> for a memorable experience in the wonder city. 
            </p>
            <h2 class="font-raleway heading-decor font-700 text-uppercase heading-5 my-4">
              Highlights of Delhi Sightseeing Tour
            </h2>
            <div class="bg-light-red">Historical Marvels</div>
            <p>
              <b>Explore the magnificent Red Fort:</b> Discover the history and architectural grandeur of this UNESCO World Heritage Site, which served as the main residence of the Mughal emperors.
            </p>
            <p>
              <b>Unravel the secrets of Qutub Minar:</b> Dive into the fascinating stories behind the tallest brick minaret in the world and marvel at its intricate carvings.
            </p>
            <p>
              <b>Step into the past at Humayun's Tomb:</b> Learn about the inspiration behind the Taj Mahal and explore the beautiful mausoleum of Emperor Humayun.
            </p>
            <div class="bg-light-red mt-4">Cultural Delights</div>
            <p>
              <b>Traverse the lanes of Old Delhi:</b> Immerse yourself in the vibrant chaos of Chandni Chowk, indulge in mouthwatering street food, and witness the blend of ancient traditions and modern life.
            </p>
            <p>
              <b>Seek spirituality at Akshardham Temple:</b> Experience the serenity and architectural splendor of this modern Hindu temple complex, which showcases the essence of Indian art, culture, and spirituality.
            </p>
            <p>
              <b>Find tranquility at Lotus Temple:</b> Discover the unique lotus-shaped Bahá'í House of Worship and embrace the peaceful ambiance of this spiritual landmark.
            </p>
            <div class="bg-light-red mt-4">Modern Marvels</div>
            <p>
              <b>Stroll through Lutyens' Delhi:</b> Marvel at the colonial-era architectural gems, such as India Gate and Rashtrapati Bhavan, in the heart of New Delhi, designed by Sir Edwin Lutyens.
            </p>
            <p>
              <b>Shop till you drop:</b> Navigate through the bustling markets of Connaught Place, Karol Bagh, and Sarojini Nagar, and explore the fusion of traditional bazaars and modern shopping malls.
            </p>
            <p>
              <b>Indulge in the culinary delights of Delhi:</b> Delve into the diverse food scene, from street food delicacies like spicy chaat and kebabs to fine dining experiences offering delectable Indian and international cuisines.
            </p>
            <div class="bg-light-red mt-4">Festivals and Events</div>
            <p>
              <b>Witness the grandeur of Republic Day Parade:</b> Get a glimpse of India's rich cultural heritage and military prowess as you watch the spectacular parade along Rajpath on 26th January.
            </p>
            <p>
              <b>Celebrate Diwali in Delhi:</b> Experience the festival of lights in the capital city, where the streets come alive with vibrant decorations, fireworks, and traditional festivities.
            </p>
            <p>
              <b>Embrace the spirit of Holi:</b> Join the exuberant celebration of colors and joy as Delhi welcomes the arrival of spring with music, dance, and playful splashes of vibrant hues.
            </p>
            <div class="bg-light-red mt-4">Day Trips and Nearby Getaways</div>
            <p>
              <b>Discover the Taj Mahal in Agra:</b> Embark on a day trip to the iconic Taj Mahal, one of the Seven Wonders of the World, and witness the epitome of eternal love.
            </p>
            <p>
              <b>Explore the Pink City of Jaipur:</b> Experience the regal charm of Jaipur's palaces, forts, and bustling markets, showcasing the rich history and vibrant culture of Rajasthan.
            </p>
            <p>
              <b>Retreat to the serenity of the Himalayan Hill Stations:</b> Escape the city's hustle and bustle by venturing into the scenic beauty of nearby hill stations like Mussoorie, Nainital, or Shimla.
            </p>
            <div class="bg-light-red mt-4">Museums and Art Galleries</div>
            <p>
              Delhi is home to several museums and art galleries that showcase the rich cultural heritage of India. The National Museum, National Gallery of Modern Art, and the Crafts Museum are worth visiting to explore Indian art, history, and craftsmanship.
            </p>
            <div class="bg-light-red mt-4">Religious Sites</div>
            <p>
              Delhi is a melting pot of various religions, and you can find numerous temples, mosques, gurdwaras, and churches across the city. The Akshardham Temple, Lotus Temple, Gurudwara Bangla Sahib, and Jama Masjid are some of the prominent religious sites that attract visitors.
            </p>
            <div class="bg-light-red mt-4">Food and Cuisine</div>
            <p>
              A paradise for food lovers, offering a diverse range of culinary delights. From street food to fine dining, the city offers a plethora of options to satisfy every palate. Don't miss trying popular dishes like butter chicken, kebabs, biryanis, chaat, chole bhature, and street desserts like jalebi and rabri.
            </p>
            <div class="bg-light-red mt-4">Shopping</div>
            <p>
              Delhi is a shopper's paradise with its bustling markets and shopping malls. From traditional handicrafts and textiles to modern fashion and accessories, you can find a wide range of products. Popular shopping destinations include Janpath, Sarojini Nagar, Karol Bagh, and Dilli Haat.
            </p>
          </div>
</section>

<!-- packages section ends -->
      <!-- footer section starts  -->

<section class="footer">
   <div class="box-container">
      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>
      <div class="box">
         <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
      </div>
      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +880-1517-089144 </a>
         <a href="#"> <i class="fas fa-phone"></i> +111-2222-333333 </a>
         <a href="#"> <i class="fas fa-envelope"></i> vishalbca@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Raval, Devbhumi dwarka 361325  </a>
      </div>
      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
      </div>
   </div>
   <div class="credit"> designed by <span>mr. Vishal Vaghela</span> | all rights reserved! </div>
</section>

<!-- footer section ends -->
<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>