<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Travel Agency :: Best Agency</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

   <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
   <script>
      $(document).ready(function(){
          $(".scroll-top").click(function() {
              $("html, body").animate({ 
                  scrollTop: 0 
              }, "slow");
              return false;
          });
      });
   </script>

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo"><img src="images/logo1.png"></a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php" class="active">package</a>
      <a href="book.php">book</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<div class="heading" style="background:url(images/header-bg-2.png) no-repeat">
   <h1>packages</h1>
</div>

<!-- packages section starts  -->

<section class="packages">

   <h1 class="heading-title">top destinations</h1>

   <div class="box-container">
   <div class="box">
         <div class="image">
            <img src="images/img-11.jpg" alt="">
         </div>
         <div class="content">
            <h3>bangladesh Tour Packages</h3>
            <p>Enjoy the Emirates with unforgettable fun with our bangladesh top selling packages!</p>
            <h2>BDT 5,900</h2>
            <div class="span8 welcome-sec">
          <h1>Customized Bangladesh Tour Packages</h1>
		  	<div class="blog-big-pic">
               <img src="images/img-11.jpg" width="197" height="100" alt="bangladesh tour packages" title="bangladesh tour packages">

          	     <br clear=" all">
                 
	       </div>
          <p align="justify">You can explore the scenic beauty of Bangladesh by getting in touch with the experienced travel agents at Naturecamp Travels. All our tour agents have years of experience customizing tour packages that fit your travel needs. A visit to the beautiful country will give you the best memories of your life which you can cherish for years.</p>
		  <p>Bangladesh is one of the best tourist destinations you can choose if you need some refreshments or planning your honeymoon. We have carved a niche in the industry by customizing the best tour package which fits your budget. Our travel agents have experience in organizing tours. They will even arrange the necessary permits so you can make the most out of the trip.</p>
		  
		  <h2>Places You Can Include In Your Bangladesh Tour Package</h2>
           <p><strong>1. The Chittagong Hill Tracts</strong></p>
		   <p align="justify">The beautiful hills scattered all over the year enhance the appeal of the place even further. Numerous tribal groups of Bangladesh stay here. Take the necessary permission from the local authority and you can trek deep inside the hills.</p>
		   <p><strong>2. Srimangal</strong></p>
		   <p align="justify">It is the northernmost part of the country and the tea capital of Bangladesh. There are numerous lush green tea gardens to click some beautiful snaps. The place is very nice and calm, attracting hundreds of tourists every year.</p>
		   <p><strong>3. Rangamati</strong></p>
		   <p align="justify">The beautiful district is located in the Chittagong Hill-Tract Areas. The Kaptai Lake is the main attraction in this region. You can spend the entire day enjoying a boat ride in the lake. It is also the home to numerous tribal groups.</p>
		   <h3>Let Us Book The Best Accommodation</h3>
		   <p align="justify">We have been praised by all our clients approaching us for Bangladesh tour packages for arranging accommodations in some of the best hotels. We know that accommodation is a major concern for travellers undertaking a trip. We have a strong network system and can do all the advance bookings. The focus is always on saving you from the last minute price surge.</p>
		   <h3>Trust Our Experienced Travel Agents</h3>
		   <p align="justify">Our travel agents leave no stone unturned in making your tour memorable. With them by your side, you don’t have to worry about how to reach Bangladesh, the accommodation or the best time to visit the country. We excel in organizing Bangladesh tour packages for tourists willing to enjoy a trip during their winter holidays. Though the summer months are also pleasant, we suggest tourists avoid monsoons.</p>
		   
		   <h2>Bangladesh Tour Package - Know the Details</h2>
		   <ul>
		     
		<li><b>Day 01: Kolkata To Dhaka</b>: Start From KOLKATA (Karunamoyee Terminus 07:00) to DHAKA (Kamalapur Terminus 20:00 expected). On arrival at the bus stand, you’ll be transferred to the Dhaka hotel for the overnight stay.</li>

		  

		  <li><b>Day 02: Dhaka Local Sightseeing and Rangamati Transfer</b>: Next morning, After Breakfast Sightseeing DHAKA,Visit Central Monument,Dhaka University,Ramna Kali Temple,Overnight travelling to the Rangamati from Dhaka.</li>


		  <li><b>Day 03: Kaptai Lake</b>: On arrival at Rangamati by morning, After arrival at the hotel at Rangamati you will be transferred to Kaptai lake for a Boat riding tour,Overnight at Rangamati. </li>
		  
		  
		  <li><b>Day 04: Rangamati to Cox’s bazar</b>: Transfer to Cox’s bazar from Rangamati via Luxury car. On arrival, you’ll be transferred to the Resort/Hotel, In the evening you can enjoy the Beach. Overnight stay in the hotel. </li>
		   
		  <li><b>Day 05: St Martins</b>: A sightseeing excursion will be done in the morning by boat from Cox’s Bazar to St. Martins and again back to Cox’s Bazar. Overnight stay in the hotel. </li>
			
		  <li><b>Day 06: Cox’s bazar</b>: Guests Can explore the Local Burmese Market of Cox’s Bazaar either by walking. Overnight staying at Cox’s bazar. </li>
			 
		 <li><b>Day 07: Cox’s bazar to Chittagong</b>: Transfer to the Chittagong for a short trip to the city and enjoy your overnight stay at the beautiful city. </li>
			  
			  
		 <li><b>Day 08: Chittagong to Dhaka</b>: Next morning, check out from the hotel and transfer to Dhaka.Night stay at Dhaka. </li>
			   
			   
		 <li><b>Day 09: Dhaka to Kolkata</b>: Dhaka to Kolkata Transfer by Flight. </li>
		     		   
		   </ul>
		   
		   <p align="center"><strong>“Contact Us To Know More”</strong></p>
		 <div style="clear:both;">&nbsp;</div>
		   
        </div>
                        <a href="book.php" class="btn">book now</a>
         </div>
    </div>
   

      
</section>

<!-- packages section ends -->
      <!-- footer section starts  -->

<section class="footer">
   <div class="box-container">
      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>
      <div class="box">
         <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
      </div>
      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +880-1517-089144 </a>
         <a href="#"> <i class="fas fa-phone"></i> +111-2222-333333 </a>
         <a href="#"> <i class="fas fa-envelope"></i> vishalbca@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Raval, Devbhumi dwarka 361325  </a>
      </div>
      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
      </div>
   </div>
   <div class="credit"> designed by <span>mr. Vishal Vaghela</span> | all rights reserved! </div>
</section>

<!-- footer section ends -->
<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>