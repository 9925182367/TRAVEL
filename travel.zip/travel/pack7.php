<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Travel Agency :: Best Agency</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

   <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
   <script>
      $(document).ready(function(){
          $(".scroll-top").click(function() {
              $("html, body").animate({ 
                  scrollTop: 0 
              }, "slow");
              return false;
          });
      });
   </script>

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo"><img src="images/logo1.png"></a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php" class="active">package</a>
      <a href="book.php">book</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<div class="heading" style="background:url(images/header-bg-2.png) no-repeat">
   <h1>packages</h1>
</div>

<!-- packages section starts  -->

<section class="packages">

   <h1 class="heading-title">top destinations</h1>

   <div class="box-container">

   <div class="box">
         <div class="image">
            <img src="images/img-7.jpg" alt="">
         </div>
         <div class="content">
            <h3>spain Tour Packages</h3>
            <p>Enjoy the Emirates with unforgettable fun with our spain top selling packages!</p>
            <h2>BDT 18,900</h2>
            <div class="mid_wrap">
        <h2 class="headtl" style="text-transform: capitalize;">Spain Tour Packages</h2>
        <div class="abttxt">
            <p>Spain is formerly known as Kingdom of Spain and it a marvelous destination. There are several tourist attractions in Spain which portrays its bright and tumultuous history. The capital Madrid of Spain houses many hot spots for the tourists and many wanderlust travelers love to explore the beauty of Spain and its various destinations on Spain tour. Some of the famous attractions of Spain are Alhambra, Mosque of Cordoba, Royal Palace of Madrid, Gothic Quarter, Casa Batllo, Costa del Sol, Plaza Mayor and Toledo Cathedral etc. Visit Spain with enticing holiday packages of Spain tour at EaseMyTrip.com and enjoy your vacations in Spain.</p>

        </div>
        <!-- ngIf: PackList.isFilter -->

        <div class="rightList">
            <style>
                .no-serch {
                    padding: 20px;
                    border: 1px solid #d6d6d6;
                    background: #fff;
                    width: 30%;
                    display: flex;
                    align-items: center;
                    flex-direction: column;
                    border-radius: 8px;
                    margin: 40px auto;
                    box-shadow: 0px 0px 8px 0px rgba(50,50,50,0.20);
                }

                .txtcnt {
                    margin-top: 15px;
                    font-weight: 600;
                }

                .ifslrTTC .inclsn, .inclsn .ifslrTTC, .ifslrTTC .inclsn {
                    display: none;
                }

                .ifslrTTC {
                    min-height: 340px;
                }

                    .ifslrTTC .pricesec {
                        padding: 0px;
                        display: none;
                    }
            </style>
            <div class="no-serch" id="no-serch-div" style="display:none">
                <img src="/holidays/Content/customize/img/no-content.png" width="80">
                <div class="txtcnt">No Package Available </div>
            </div>
            <div class="listpnl">
                
                <!-- ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638398124956710727/SightSeeing/SightSeeingVzZVaW.jpg" src="https://media.easemytrip.com/media/Deal/DL638398124956710727/SightSeeing/SightSeeingVzZVaW.jpg"></div>
                        
                        <p class="tnight ng-binding">10 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Marvellous Spanish Fiesta with Portugal</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Lisbon | 1N Seville | 2N Granada | 2N Madrid | 1N Valencia | 2N Barcelona</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 282990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638398124956710727">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 206290
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638398124956710727" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../marvellous-spanish-fiesta-with-portugal-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../marvellous-spanish-fiesta-with-portugal-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">35513</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638085374739011382/Attraction/Attraction6A87H7.jpg" src="https://media.easemytrip.com/media/Deal/DL638085374739011382/Attraction/Attraction6A87H7.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Weekend in Spain</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Madrid | 2N Barcelona</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638085374739011382" type="radio" id="htl_01DL638085374739011382Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638085374739011382Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638085374739011382" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 135133
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹95814
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638085374739011382" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../weekend-in-spain-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../weekend-in-spain-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">23534</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638094848891433282/SightSeeing/SightSeeingyrCQLz.jpg" src="https://media.easemytrip.com/media/Deal/DL638094848891433282/SightSeeing/SightSeeingyrCQLz.jpg"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Spain Supersaver - 5 Nights</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Madrid |  1N Seville |  2N Barcelona</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638094848891433282" type="radio" id="htl_01DL638094848891433282Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638094848891433282Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638094848891433282" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 131580
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹106963
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638094848891433282" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../spain-supersaver-5-nights-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../spain-supersaver-5-nights-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">22936</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638100744075011121/Attraction/Attractionl4hDy0.jpg" src="https://media.easemytrip.com/media/Deal/DL638100744075011121/Attraction/Attractionl4hDy0.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Travel Spain</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Madrid | 1N Cordoba | 1N Seville | 1N Granada</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638100744075011121" type="radio" id="htl_01DL638100744075011121Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638100744075011121Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638100744075011121" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 160403
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹126112
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638100744075011121" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../travel-spain-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../travel-spain-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">27788</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638100781937741787/SightSeeing/SightSeeingFg9gHW.jpg" src="https://media.easemytrip.com/media/Deal/DL638100781937741787/SightSeeing/SightSeeingFg9gHW.jpg"></div>
                        
                        <p class="tnight ng-binding">7 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Spanish excursion</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Madrid |  1N Cordoba | 1N Seville | 1N Granada | 2N Barcelona</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638100781937741787" type="radio" id="htl_01DL638100781937741787Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638100781937741787Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638100781937741787" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 205602
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹163226
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638100781937741787" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../spanish-excursion-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../spanish-excursion-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">35397</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638100837106529827/Attraction/AttractionDEQMEx.jpg" src="https://media.easemytrip.com/media/Deal/DL638100837106529827/Attraction/AttractionDEQMEx.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Enchanting Spain</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Madrid | 1N Seville | 1N Cordoba</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638100837106529827" type="radio" id="htl_01DL638100837106529827Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638100837106529827Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638100837106529827" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 136122
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹95478
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638100837106529827" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../enchanting-spain-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../enchanting-spain-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">23701</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638101567985114390/SightSeeing/SightSeeingnDWie7.jpg" src="https://media.easemytrip.com/media/Deal/DL638101567985114390/SightSeeing/SightSeeingnDWie7.jpg"></div>
                        
                        <p class="tnight ng-binding">7 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Fascinating Spain</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Barcelona | 1N Granada | 1N Seville | 1N Cordoba | 2N Madrid</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638101567985114390" type="radio" id="htl_01DL638101567985114390Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638101567985114390Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">BCN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">BCN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638101567985114390" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 98653
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹40800
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638101567985114390" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../fascinating-spain-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../fascinating-spain-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">17199</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638101609459869104/SightSeeing/SightSeeingFQ4HJO.jpg" src="https://media.easemytrip.com/media/Deal/DL638101609459869104/SightSeeing/SightSeeingFQ4HJO.jpg"></div>
                        
                        <p class="tnight ng-binding">7 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Gorgeous Spain</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Madrid | 1N Cordoba | 1N Seville | 1N Granada | 2N Barcelona</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638101609459869104" type="radio" id="htl_01DL638101609459869104Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638101609459869104Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638101609459869104" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 199557
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹157730
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638101609459869104" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../gorgeous-spain-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../gorgeous-spain-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">34379</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638120681240518447/SightSeeing/SightSeeing3XCthj.jpg" src="https://media.easemytrip.com/media/Deal/DL638120681240518447/SightSeeing/SightSeeing3XCthj.jpg"></div>
                        
                        <p class="tnight ng-binding">9 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Soulful France and Spain</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Paris | 2N Nice | 2N Barcelona | 2N Madrid</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638120681240518447" type="radio" id="htl_01DL638120681240518447Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638120681240518447Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">CDG</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">CDG</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638120681240518447" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 230118
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹236779
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638120681240518447" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../soulful-france-and-spain-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../soulful-france-and-spain-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">39524</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638126737846323276/Transfer/TransfernuY1b0.jpg" src="https://media.easemytrip.com/media/Deal/DL638126737846323276/Transfer/TransfernuY1b0.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Vibrant Madrid and Barcelona</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Madrid | 3N Barcelona</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638126737846323276" type="radio" id="htl_01DL638126737846323276Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638126737846323276Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638126737846323276" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 152200
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹92789
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638126737846323276" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../vibrant-madrid-and-barcelona-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../vibrant-madrid-and-barcelona-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">26407</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638127526851060885/SightSeeing/SightSeeing91Ojgl.jpg" src="https://media.easemytrip.com/media/Deal/DL638127526851060885/SightSeeing/SightSeeing91Ojgl.jpg"></div>
                        
                        <p class="tnight ng-binding">9 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Memorable Trio of Spain</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Madrid | 3N Valencia | 3N Barcelona</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638127526851060885" type="radio" id="htl_01DL638127526851060885Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638127526851060885Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638127526851060885" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 173279
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹119614
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638127526851060885" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../memorable-trio-of-spain-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../memorable-trio-of-spain-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">29956</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638143154518372128/SightSeeing/SightSeeingGXbMl1.jpg" src="https://media.easemytrip.com/media/Deal/DL638143154518372128/SightSeeing/SightSeeingGXbMl1.jpg"></div>
                        
                        <p class="tnight ng-binding">9 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Spanish trio</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Madrid | 3N Valencia | 3N Barcelona</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638143154518372128" type="radio" id="htl_01DL638143154518372128Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638143154518372128Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">MAD</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638143154518372128" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 152049
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹115827
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638143154518372128" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../spanish-trio-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../spanish-trio-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">26382</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638321035530810672/SightSeeing/SightSeeingDxPJO2.jpg" src="https://media.easemytrip.com/media/Deal/DL638321035530810672/SightSeeing/SightSeeingDxPJO2.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Majestic Spain Expedition</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Lisbon | 2N Seville | 2N Madrid</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 81990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638321035530810672">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 77990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638321035530810672" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../majestic-spain-expedition-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../majestic-spain-expedition-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">13755</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638321052839493381/SightSeeing/SightSeeingZJxjpF.jpg" src="https://media.easemytrip.com/media/Deal/DL638321052839493381/SightSeeing/SightSeeingZJxjpF.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Enchanting Spain Explorer</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Lisbon | 2N Madrid | 2N Barcelona</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 87790
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638321052839493381">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 85990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638321052839493381" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../enchanting-spain-explorer-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../enchanting-spain-explorer-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">15088</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638321079512125874/SightSeeing/SightSeeingCQLjCH.jpg" src="https://media.easemytrip.com/media/Deal/DL638321079512125874/SightSeeing/SightSeeingCQLjCH.jpg"></div>
                        
                        <p class="tnight ng-binding">8 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">White Villages and Spanish Splendors Expedition</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Madrid | 1N Córdoba | 2N Seville | 2N Granada | 1N Madrid</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 150790
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638321079512125874">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 134990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638321079512125874" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../white-villages-and-spanish-splendors-expedition-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../white-villages-and-spanish-splendors-expedition-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">23510</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638321119409156519/SightSeeing/SightSeeingHhGjay.jpg" src="https://media.easemytrip.com/media/Deal/DL638321119409156519/SightSeeing/SightSeeingHhGjay.jpg"></div>
                        
                        <p class="tnight ng-binding">11 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Essential Spain Getaway</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Madrid | 2N Lisbon | 2N Seville | 2N Granada | 3N Barcelona</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 149990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638321119409156519">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 139990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638321119409156519" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../essential-spain-getaway-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../essential-spain-getaway-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">24352</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638321144937610089/SightSeeing/SightSeeing3fFNOq.jpg" src="https://media.easemytrip.com/media/Deal/DL638321144937610089/SightSeeing/SightSeeing3fFNOq.jpg"></div>
                        
                        <p class="tnight ng-binding">7 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Spanish Splendor Tour</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Barcelona | 2N Mallorca | 2N Ibiza | 1N Barcelona</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 210990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638321144937610089">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 193990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638321144937610089" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../spanish-splendor-tour-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../spanish-splendor-tour-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">33442</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638321168083208907/SightSeeing/SightSeeing81vs0U.jpg" src="https://media.easemytrip.com/media/Deal/DL638321168083208907/SightSeeing/SightSeeing81vs0U.jpg"></div>
                        
                        <p class="tnight ng-binding">7 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Heart of Spain Experience</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Madrid | 1N Córdoba | 1N Seville | 1N Granada | 2N Barcelona</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 130990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638321168083208907">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 100990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638321168083208907" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../heart-of-spain-experience-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../heart-of-spain-experience-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">17787</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL637699770562975301/SightSeeing/SightSeeingGi24nK.jpg" src="https://media.easemytrip.com/media/Deal/DL637699770562975301/SightSeeing/SightSeeingGi24nK.jpg"></div>
                        
                        <p class="tnight ng-binding">8 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Essential Spain and Portugal (Guided Tour)</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Madrid| 1N Coimbra| 2N Lisbon| 2N Seville</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 155990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL637699770562975301">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 115990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL637699770562975301" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../essential-spain-and-portugal-guided-tour-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../essential-spain-and-portugal-guided-tour-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">20312</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL637699788085106240/SightSeeing/SightSeeingwrx57d.jpg" src="https://media.easemytrip.com/media/Deal/DL637699788085106240/SightSeeing/SightSeeingwrx57d.jpg"></div>
                        
                        <p class="tnight ng-binding">19 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Essential Spain, Portugal &amp; Morocco (Group Tour)</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Madrid | 1N Salamanca | 2N Porto | 2N Lisbon | 2N Seville | 2N Granada | 1N Madrid | 1N Casablanca | 1N Rabat | 2N Fes | 1N Erfoud | 1N Ourzazate | 1N Marrakech</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 465990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL637699788085106240">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 365990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL637699788085106240" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../essential-spain-portugal-and-morocco-group-tour-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../essential-spain-portugal-and-morocco-group-tour-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">62396</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/0mschsto/jt1_5979.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/0mschsto/jt1_5979.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">22 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Best of Spain and Portugal</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Social travel for 18-35 yrs ONLY</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535097832305" type="radio" id="htl_01TTC638611535097832305Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535097832305Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535097832305">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 201346
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535097832305" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-best-of-spain-and-portugal-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-best-of-spain-and-portugal-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">34680</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/wm4b2ykl/0157eurs2020.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/wm4b2ykl/0157eurs2020.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">20 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Spain, Portugal and Morocco Highlights</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Social travel for 18-35 yrs ONLY</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535108767796" type="radio" id="htl_01TTC638611535108767796Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535108767796Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535108767796">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 287577
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535108767796" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-spain-portugal-and-morocco-highlights-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-spain-portugal-and-morocco-highlights-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">49196</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/3d5g2mr3/3074eurs2022-1.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/3d5g2mr3/3074eurs2022-1.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">8 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Barcelona, Ibiza and Mallorca</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Social travel for 18-35 yrs ONLY</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535110761309" type="radio" id="htl_01TTC638611535110761309Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535110761309Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535110761309">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 180691
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535110761309" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-barcelona-ibiza-and-mallorca-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-barcelona-ibiza-and-mallorca-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">31203</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/6251/easy-pace-spain-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/6251/easy-pace-spain-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">9 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Easy Pace Spain</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Business class touring</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535134709158" type="radio" id="htl_01TTC638611535134709158Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535134709158Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535134709158">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 306049
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535134709158" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-easy-pace-spain-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-easy-pace-spain-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">52306</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/6248/best-spain-portugal-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/6248/best-spain-portugal-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">14 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Best of Spain and Portugal</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Business class touring</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535143768640" type="radio" id="htl_01TTC638611535143768640Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535143768640Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535143768640">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 285268
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535143768640" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-best-of-spain-and-portugal-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-best-of-spain-and-portugal-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">48808</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/13528/spanish-wonder-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/13528/spanish-wonder-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">8 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Spanish Wonder</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Tour differently</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535179706832" type="radio" id="htl_01TTC638611535179706832Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535179706832Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535179706832">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 162471
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535179706832" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-spanish-wonder-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-spanish-wonder-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">28136</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/13514/mediterranean-highlights-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/13514/mediterranean-highlights-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">12 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Mediterranean Highlights</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Tour differently</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535184081659" type="radio" id="htl_01TTC638611535184081659Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535184081659Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535184081659">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 277984
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535184081659" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-mediterranean-highlights-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-mediterranean-highlights-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">47581</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/13542/northern-spain-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/13542/northern-spain-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">10 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Northern Spain</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Tour differently</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535184459863" type="radio" id="htl_01TTC638611535184459863Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535184459863Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535184459863">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 226598
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535184459863" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-northern-spain-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-northern-spain-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">38931</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/13334/alhambra-palace-granada-spain.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/13334/alhambra-palace-granada-spain.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">14 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Best of Spain</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Tour differently</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535185095059" type="radio" id="htl_01TTC638611535185095059Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535185095059Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535185095059">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 339677
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535185095059" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-best-of-spain-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-best-of-spain-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">57967</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/13505/great-iberian-cities-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/13505/great-iberian-cities-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">8 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Great Iberian Cities</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Tour differently</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535188906126" type="radio" id="htl_01TTC638611535188906126Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535188906126Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535188906126">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 192698
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535188906126" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-great-iberian-cities-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-great-iberian-cities-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">33225</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/13511/highlights-spain-portugal-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/13511/highlights-spain-portugal-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">12 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Highlights of Spain and Portugal</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Tour differently</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535196269008" type="radio" id="htl_01TTC638611535196269008Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535196269008Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535196269008">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 218769
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535196269008" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-highlights-of-spain-and-portugal-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-highlights-of-spain-and-portugal-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">37613</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/13518/spain-morocco-portugal-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/13518/spain-morocco-portugal-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">15 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Spain, Morocco and Portugal</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Tour differently</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535206167913" type="radio" id="htl_01TTC638611535206167913Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535206167913Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535206167913">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 301851
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535206167913" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-spain-morocco-and-portugal-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-spain-morocco-and-portugal-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">51599</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/15577/iberian-explorer-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/15577/iberian-explorer-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">12 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Iberian Explorer</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Free and Easy Touring</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535223575210" type="radio" id="htl_01TTC638611535223575210Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535223575210Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535223575210">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 139801
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535223575210" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-iberian-explorer-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-iberian-explorer-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">24320</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  -->




            </div>
        </div>


    </div>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

    </div>
      
</section>

<!-- packages section ends -->
      <!-- footer section starts  -->

<section class="footer">
   <div class="box-container">
      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>
      <div class="box">
         <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
      </div>
      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +880-1517-089144 </a>
         <a href="#"> <i class="fas fa-phone"></i> +111-2222-333333 </a>
         <a href="#"> <i class="fas fa-envelope"></i> vishalbca@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Raval, Devbhumi dwarka 361325  </a>
      </div>
      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
      </div>
   </div>
   <div class="credit"> designed by <span>mr. Vishal Vaghela</span> | all rights reserved! </div>
</section>

<!-- footer section ends -->
<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>