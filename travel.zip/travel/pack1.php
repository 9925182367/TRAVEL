<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Travel Agency :: Best Agency</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

   <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
   <script>
      $(document).ready(function(){
          $(".scroll-top").click(function() {
              $("html, body").animate({ 
                  scrollTop: 0 
              }, "slow");
              return false;
          });
      });
   </script>

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo"><img src="images/logo1.png"></a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php" class="active">package</a>
      <a href="book.php">book</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<div class="heading" style="background:url(images/header-bg-2.png) no-repeat">
   <h1>packages</h1>
</div>

<!-- packages section starts  -->

<section class="packages">

   <h1 class="heading-title">top destinations</h1>

   <div class="box-container">

      <div class="box">
         <div class="image">
            <img src="images/img-1.jpg" alt="">
         </div>
         <div class="content">
            <h3>Dubai Tour Packages</h3>
            <p>Enjoy the Emirates with unforgettable fun with our Dubai top selling packages!</p>
            <h2>BDT 10,900</h2>
            <div class="mid_wrap">
        <h2 class="headtl" style="text-transform: capitalize;">Dubai Tour Packages</h2>
        <div class="abttxt">
            <p>Dubai is well known city in United Arab Emirates and it is located on the southeast coast of the Persian Gulf; moreover it is one of the major emirate among the seven. Dubai has emerged as a business hub and as a global city in recent years and the city have several iconic landmarks and skyscrapers like the famous Dubai mall, Palm Jumeirah and Burj Khalifa etc. There are other attractions also in the city which magnetize numerous tourists from all over the world which one can explore on Dubai tour. According to a study Dubai is considered as the 22nd most expensive city in the whole world and it is also reputed as one of the astounding places to live in Middle East. Explore the beauty of this place with the amazing International holiday packages at EaseMyTrip.com and enjoy your holidays in the marvelous city of UAE.</p>

        </div>
        <!-- ngIf: PackList.isFilter -->

        <div class="rightList">
            <style>
                .no-serch {
                    padding: 20px;
                    border: 1px solid #d6d6d6;
                    background: #fff;
                    width: 30%;
                    display: flex;
                    align-items: center;
                    flex-direction: column;
                    border-radius: 8px;
                    margin: 40px auto;
                    box-shadow: 0px 0px 8px 0px rgba(50,50,50,0.20);
                }

                .txtcnt {
                    margin-top: 15px;
                    font-weight: 600;
                }

                .ifslrTTC .inclsn, .inclsn .ifslrTTC, .ifslrTTC .inclsn {
                    display: none;
                }

                .ifslrTTC {
                    min-height: 340px;
                }

                    .ifslrTTC .pricesec {
                        padding: 0px;
                        display: none;
                    }
            </style>
            <div class="no-serch" id="no-serch-div" style="display:none">
                <img src="/holidays/Content/customize/img/no-content.png" width="80">
                <div class="txtcnt">No Package Available </div>
            </div>
            <div class="listpnl">
                
                <!-- ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638423098463838945/SightSeeing/SightSeeing7tDVSj.jpg" src="https://media.easemytrip.com/media/Deal/DL638423098463838945/SightSeeing/SightSeeing7tDVSj.jpg"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Fantastic Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">5N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 85990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638423098463838945">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 69900
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638423098463838945" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../fantastic-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../fantastic-dubai-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">12407</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638259767687184352/Transfer/Transferh8Ugb6.jpg" src="https://media.easemytrip.com/media/Deal/DL638259767687184352/Transfer/Transferh8Ugb6.jpg"></div>
                        
                        <p class="tnight ng-binding">3 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dubai Kids Go Free</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 67990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638259767687184352">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 56990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638259767687184352" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../dubai-kids-go-free-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../dubai-kids-go-free-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">10255</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL637368468102333885/SightSeeing/SightSeeingvjlMBK.jpg" src="https://media.easemytrip.com/media/Deal/DL637368468102333885/SightSeeing/SightSeeingvjlMBK.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Ultimate Dubai Experience</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">04 Nights Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 22990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL637368468102333885">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 16990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL637368468102333885" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ultimate-dubai-experience-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ultimate-dubai-experience-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">3588</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638259737708986994/SightSeeing/SightSeeinguVpLu6.jpg" src="https://media.easemytrip.com/media/Deal/DL638259737708986994/SightSeeing/SightSeeinguVpLu6.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Glittering Dubai Getaway</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 65990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638259737708986994">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 55990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638259737708986994" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../glittering-dubai-getaway-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../glittering-dubai-getaway-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">10088</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638259745369109830/SightSeeing/SightSeeingnN5too.jpg" src="https://media.easemytrip.com/media/Deal/DL638259745369109830/SightSeeing/SightSeeingnN5too.jpg"></div>
                        
                        <p class="tnight ng-binding">2 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Unforgettable Yas Island with Kids Go Free</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">02N Yas Island</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 59990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638259745369109830">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 36990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638259745369109830" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../unforgettable-yas-island-with-kids-go-free-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../unforgettable-yas-island-with-kids-go-free-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">6922</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638258899838943235/SightSeeing/SightSeeingXnjsVS.png" src="https://media.easemytrip.com/media/Deal/DL638258899838943235/SightSeeing/SightSeeingXnjsVS.png"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Discover Dubai and Yas Island with 4 Star</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Dubai | 1N Abu Dhabi</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 57990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638258899838943235">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 44990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638258899838943235" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../discover-dubai-and-yas-island-with-4-star-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../discover-dubai-and-yas-island-with-4-star-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">8255</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638259712288296712/SightSeeing/SightSeeingamiYBi.jpg" src="https://media.easemytrip.com/media/Deal/DL638259712288296712/SightSeeing/SightSeeingamiYBi.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Romantic Escapes in Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai | 2N Abu Dhabi</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 78990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638259712288296712">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 59990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638259712288296712" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../romantic-escapes-in-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../romantic-escapes-in-dubai-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">10755</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638259772712074768/SightSeeing/SightSeeingYUbabU.jpg" src="https://media.easemytrip.com/media/Deal/DL638259772712074768/SightSeeing/SightSeeingYUbabU.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Luxury Dubai and Radisson Blu Hotel Yas Island Stay</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Dubai | 1N Abu Dhabi</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 63990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638259772712074768">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 48990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638259772712074768" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../luxury-dubai-and-radisson-blu-hotel-yas-island-stay-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../luxury-dubai-and-radisson-blu-hotel-yas-island-stay-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">8922</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638259839096981783/SightSeeing/SightSeeingQUWpDr.jpg" src="https://media.easemytrip.com/media/Deal/DL638259839096981783/SightSeeing/SightSeeingQUWpDr.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Best of Dubai with Ferrari World</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">04N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 92590
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638259839096981783">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 78590
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638259839096981783" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../best-of-dubai-with-ferrari-world-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../best-of-dubai-with-ferrari-world-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">13855</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638058405983258112/SightSeeing/SightSeeing0QQnb4.jpg" src="https://media.easemytrip.com/media/Deal/DL638058405983258112/SightSeeing/SightSeeing0QQnb4.jpg"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dandy Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">5N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638058405983258112" type="radio" id="htl_01DL638058405983258112Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638058405983258112Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638058405983258112" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 42823
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹38769
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638058405983258112" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../dandy-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../dandy-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">7894</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638058539687955606/SightSeeing/SightSeeingJewRey.jpg" src="https://media.easemytrip.com/media/Deal/DL638058539687955606/SightSeeing/SightSeeingJewRey.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dubai Delights</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638058539687955606" type="radio" id="htl_01DL638058539687955606Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638058539687955606Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638058539687955606" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 41034
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹34453
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638058539687955606" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../dubai-delights-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../dubai-delights-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">7596</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638058610026390056/Attraction/AttractionyvvM24.jpg" src="https://media.easemytrip.com/media/Deal/DL638058610026390056/Attraction/AttractionyvvM24.jpg"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dubai A Distinguished Experience</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">5N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638058610026390056" type="radio" id="htl_01DL638058610026390056Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638058610026390056Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638058610026390056" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 63777
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹61736
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638058610026390056" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../dubai-a-distinguished-experience-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../dubai-a-distinguished-experience-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">11386</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638058623354328690/SightSeeing/SightSeeingg8P1ma.jpg" src="https://media.easemytrip.com/media/Deal/DL638058623354328690/SightSeeing/SightSeeingg8P1ma.jpg"></div>
                        
                        <p class="tnight ng-binding">3 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Demystifying Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638058623354328690" type="radio" id="htl_01DL638058623354328690Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638058623354328690Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638058623354328690" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 34322
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹25435
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638058623354328690" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../demystifying-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../demystifying-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">6477</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638073267909225798/SightSeeing/SightSeeingLD4gdX.jpg" src="https://media.easemytrip.com/media/Deal/DL638073267909225798/SightSeeing/SightSeeingLD4gdX.jpg"></div>
                        
                        <p class="tnight ng-binding">3 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Unforgettable Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638073267909225798" type="radio" id="htl_01DL638073267909225798Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638073267909225798Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638073267909225798" type="radio" id="htl_01DL638073267909225798Premium" value="Premium" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638073267909225798Premium" class="ng-binding">
                                                        5
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638073267909225798" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 55390
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹46466
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638073267909225798" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../unforgettable-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../unforgettable-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">9988</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638074090179720808/Dam/DamAZewiR.jpg" src="https://media.easemytrip.com/media/Deal/DL638074090179720808/Dam/DamAZewiR.jpg"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dynamic Days in Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">5N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638074090179720808" type="radio" id="htl_01DL638074090179720808Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638074090179720808Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638074090179720808" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 82307
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹80082
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638074090179720808" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../dynamic-days-in-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../dynamic-days-in-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">14475</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638074126142296422/Attraction/AttractionaDBmTo.jpg" src="https://media.easemytrip.com/media/Deal/DL638074126142296422/Attraction/AttractionaDBmTo.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Daydreaming about Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn ng-hide" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638074126142296422" type="radio" id="htl_01DL638074126142296422Premium" value="Premium" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638074126142296422Premium" class="ng-binding">
                                                        5
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638074126142296422" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 35002
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹31906
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638074126142296422" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../daydreaming-about-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../daydreaming-about-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">6590</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638074134656808405/SightSeeing/SightSeeingJAoh1z.jpg" src="https://media.easemytrip.com/media/Deal/DL638074134656808405/SightSeeing/SightSeeingJAoh1z.jpg"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Desirable Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">5N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638074134656808405" type="radio" id="htl_01DL638074134656808405Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638074134656808405Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638074134656808405" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 50411
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹45086
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638074134656808405" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../desirable-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../desirable-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">9159</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638076638921053076/Attraction/Attraction7qWbAO.jpg" src="https://media.easemytrip.com/media/Deal/DL638076638921053076/Attraction/Attraction7qWbAO.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">A Date with Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638076638921053076" type="radio" id="htl_01DL638076638921053076Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638076638921053076Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638076638921053076" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 35310
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹28486
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638076638921053076" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../a-date-with-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../a-date-with-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">6642</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638076649661341606/SightSeeing/SightSeeingxSuRZb.jpg" src="https://media.easemytrip.com/media/Deal/DL638076649661341606/SightSeeing/SightSeeingxSuRZb.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Tunes of Dubai’s Dunes</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638076649661341606" type="radio" id="htl_01DL638076649661341606Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638076649661341606Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638076649661341606" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 66620
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹58752
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638076649661341606" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../tunes-of-dubai’s-dunes-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../tunes-of-dubai’s-dunes-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">11860</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638076662660687590/SightSeeing/SightSeeingLjCfNR.jpg" src="https://media.easemytrip.com/media/Deal/DL638076662660687590/SightSeeing/SightSeeingLjCfNR.jpg"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Love in Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai | 1N Dubai Palm</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638076662660687590" type="radio" id="htl_01DL638076662660687590Premium" value="Premium" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638076662660687590Premium" class="ng-binding">
                                                        5
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638076662660687590" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 51287
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹52773
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638076662660687590" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../love-in-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../love-in-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">9305</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638076722619147756/SightSeeing/SightSeeinglkrm4B.jpg" src="https://media.easemytrip.com/media/Deal/DL638076722619147756/SightSeeing/SightSeeinglkrm4B.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Once Upon a Time in Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai | 2N Dubai Palm</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn ng-hide" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638076722619147756" type="radio" id="htl_01DL638076722619147756Premium" value="Premium" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638076722619147756Premium" class="ng-binding">
                                                        5
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638076722619147756" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 77355
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹120697
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638076722619147756" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../once-upon-a-time-in-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../once-upon-a-time-in-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">13649</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638100948555039526/SightSeeing/SightSeeingbz2TeZ.jpg" src="https://media.easemytrip.com/media/Deal/DL638100948555039526/SightSeeing/SightSeeingbz2TeZ.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Distinct Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638100948555039526" type="radio" id="htl_01DL638100948555039526Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638100948555039526Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638100948555039526" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 45249
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹41805
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638100948555039526" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../distinct-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../distinct-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">8298</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638101764221098874/SightSeeing/SightSeeingmA3dia.jpg" src="https://media.easemytrip.com/media/Deal/DL638101764221098874/SightSeeing/SightSeeingmA3dia.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dubai Shopping Fiesta</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638101764221098874" type="radio" id="htl_01DL638101764221098874Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638101764221098874Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638101764221098874" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 68135
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹59141
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638101764221098874" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../dubai-shopping-fiesta-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../dubai-shopping-fiesta-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">12113</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638102436229499714/SightSeeing/SightSeeingDayvyJ.jpg" src="https://media.easemytrip.com/media/Deal/DL638102436229499714/SightSeeing/SightSeeingDayvyJ.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Charismatic Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638102436229499714" type="radio" id="htl_01DL638102436229499714Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638102436229499714Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638102436229499714" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 66588
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹57735
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638102436229499714" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../charismatic-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../charismatic-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">11855</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638102455006490236/SightSeeing/SightSeeingtz85N3.jpg" src="https://media.easemytrip.com/media/Deal/DL638102455006490236/SightSeeing/SightSeeingtz85N3.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Captivating Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638102455006490236" type="radio" id="htl_01DL638102455006490236Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638102455006490236Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638102455006490236" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 71004
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹61677
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638102455006490236" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../captivating-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../captivating-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">12591</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638102571394051735/SightSeeing/SightSeeingRdeoc1.jpg" src="https://media.easemytrip.com/media/Deal/DL638102571394051735/SightSeeing/SightSeeingRdeoc1.jpg"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Spellbinding Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">5N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638102571394051735" type="radio" id="htl_01DL638102571394051735Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638102571394051735Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638102571394051735" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 99062
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹87593
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638102571394051735" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../spellbinding-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../spellbinding-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">17267</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638109460048311173/SightSeeing/SightSeeingij7YCB.jpg" src="https://media.easemytrip.com/media/Deal/DL638109460048311173/SightSeeing/SightSeeingij7YCB.jpg"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Delightful Dubai with 2 Nights at Yas Island Abu Dhabi</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Dubai | 2N Abu Dhabi</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638109460048311173" type="radio" id="htl_01DL638109460048311173Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638109460048311173Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638109460048311173" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 86823
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹102584
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638109460048311173" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../delightful-dubai-with-2-nights-at-yas-island-abu-dhabi-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../delightful-dubai-with-2-nights-at-yas-island-abu-dhabi-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">15227</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638121500385910403/SightSeeing/SightSeeing5j2MN5.jpg" src="https://media.easemytrip.com/media/Deal/DL638121500385910403/SightSeeing/SightSeeing5j2MN5.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dubai for Adventure Lovers</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638121500385910403" type="radio" id="htl_01DL638121500385910403Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638121500385910403Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638121500385910403" type="radio" id="htl_01DL638121500385910403Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638121500385910403Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638121500385910403" type="radio" id="htl_01DL638121500385910403Premium" value="Premium" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638121500385910403Premium" class="ng-binding">
                                                        5
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638121500385910403" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 57489
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹45067
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638121500385910403" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../dubai-for-adventure-lovers-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../dubai-for-adventure-lovers-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">10338</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638121530168907537/SightSeeing/SightSeeingdnIdwH.jpg" src="https://media.easemytrip.com/media/Deal/DL638121530168907537/SightSeeing/SightSeeingdnIdwH.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dubai for Food Lovers</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638121530168907537" type="radio" id="htl_01DL638121530168907537Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638121530168907537Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638121530168907537" type="radio" id="htl_01DL638121530168907537Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638121530168907537Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638121530168907537" type="radio" id="htl_01DL638121530168907537Premium" value="Premium" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638121530168907537Premium" class="ng-binding">
                                                        5
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638121530168907537" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 46557
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹40177
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638121530168907537" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../dubai-for-food-lovers-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../dubai-for-food-lovers-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">8516</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638121610952469998/Transfer/Transferkdds0k.jpg" src="https://media.easemytrip.com/media/Deal/DL638121610952469998/Transfer/Transferkdds0k.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dubai for Party Lovers</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638121610952469998" type="radio" id="htl_01DL638121610952469998Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638121610952469998Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638121610952469998" type="radio" id="htl_01DL638121610952469998Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638121610952469998Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638121610952469998" type="radio" id="htl_01DL638121610952469998Premium" value="Premium" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638121610952469998Premium" class="ng-binding">
                                                        5
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638121610952469998" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 49981
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹44909
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638121610952469998" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../dubai-for-party-lovers-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../dubai-for-party-lovers-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">9087</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638121657140780934/SightSeeing/SightSeeingsl8YEm.jpg" src="https://media.easemytrip.com/media/Deal/DL638121657140780934/SightSeeing/SightSeeingsl8YEm.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dubai for Shopaholics</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638121657140780934" type="radio" id="htl_01DL638121657140780934Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638121657140780934Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638121657140780934" type="radio" id="htl_01DL638121657140780934Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638121657140780934Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638121657140780934" type="radio" id="htl_01DL638121657140780934Premium" value="Premium" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638121657140780934Premium" class="ng-binding">
                                                        5
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638121657140780934" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 50405
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹43094
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638121657140780934" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../dubai-for-shopaholics-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../dubai-for-shopaholics-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">9158</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638570080494071269/SightSeeing/SightSeeingGNZa1U.jpg" src="https://media.easemytrip.com/media/Deal/DL638570080494071269/SightSeeing/SightSeeingGNZa1U.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Enchanted Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4 Nights Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 28999
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638570080494071269">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 18999
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638570080494071269" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../enchanted-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../enchanted-dubai-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">3923</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL637667160851879108/Attraction/Attraction8rxQur.png" src="https://media.easemytrip.com/media/Deal/DL637667160851879108/Attraction/Attraction8rxQur.png"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Marvellous Dubai with IMG Worlds of Adventure</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">04 Nights Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 49990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL637667160851879108">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 38990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL637667160851879108" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../marvellous-dubai-with-img-worlds-of-adventure-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../marvellous-dubai-with-img-worlds-of-adventure-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">7255</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638034215971610479/SightSeeing/SightSeeingU7GjRW.png" src="https://media.easemytrip.com/media/Deal/DL638034215971610479/SightSeeing/SightSeeingU7GjRW.png"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dubai with Iconic Burj Al Arab Jumeirah</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 38990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638034215971610479">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 29990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638034215971610479" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../dubai-with-iconic-burj-al-arab-jumeirah-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../dubai-with-iconic-burj-al-arab-jumeirah-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">5755</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638046293853273421/Attraction/AttractionIbX6iI.jpg" src="https://media.easemytrip.com/media/Deal/DL638046293853273421/Attraction/AttractionIbX6iI.jpg"></div>
                        
                        <p class="tnight ng-binding">3 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dreamy Dubai</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638046293853273421" type="radio" id="htl_01DL638046293853273421Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638046293853273421Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638046293853273421" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 34405
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹24721
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638046293853273421" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../dreamy-dubai-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../dreamy-dubai-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">6491</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638046295682957364/SightSeeing/SightSeeingFH59Yq.jpg" src="https://media.easemytrip.com/media/Deal/DL638046295682957364/SightSeeing/SightSeeingFH59Yq.jpg"></div>
                        
                        <p class="tnight ng-binding">3 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dubai Explorer Family Package</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Dubai</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638046295682957364" type="radio" id="htl_01DL638046295682957364Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638046295682957364Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">DXB</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638046295682957364" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 40611
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹29359
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638046295682957364" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../dubai-explorer-family-package-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../dubai-explorer-family-package-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">7525</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  -->




            </div>
        </div>


    </div>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>
</section>

<!-- packages section ends -->
      <!-- footer section starts  -->

<section class="footer">
   <div class="box-container">
      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>
      <div class="box">
         <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
      </div>
      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +880-1517-089144 </a>
         <a href="#"> <i class="fas fa-phone"></i> +111-2222-333333 </a>
         <a href="#"> <i class="fas fa-envelope"></i> vishalbca@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Raval, Devbhumi dwarka 361325  </a>
      </div>
      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
      </div>
   </div>
   <div class="credit"> designed by <span>mr. Vishal Vaghela</span> | all rights reserved! </div>
</section>

<!-- footer section ends -->
<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>