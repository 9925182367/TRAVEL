<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Travel Agency :: Best Agency</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

   <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
   <script>
      $(document).ready(function(){
          $(".scroll-top").click(function() {
              $("html, body").animate({ 
                  scrollTop: 0 
              }, "slow");
              return false;
          });
      });
   </script>

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo"><img src="images/logo1.png"></a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php" class="active">package</a>
      <a href="book.php">book</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<div class="heading" style="background:url(images/header-bg-2.png) no-repeat">
   <h1>packages</h1>
</div>

<!-- packages section starts  -->

<section class="packages">

   <h1 class="heading-title">top destinations</h1>

   <div class="box-container">

   <div class="box">
         <div class="image">
            <img src="images/img-6.jpg" alt="">
         </div>
         <div class="content">
            <h3>singapur Tour Packages</h3>
            <p>Enjoy the Emirates with unforgettable fun with our singapur top selling packages!</p>
            <h2>BDT 12,900</h2>
            <div class="mid_wrap">
        <h2 class="headtl" style="text-transform: capitalize;">Singapore Tour Packages</h2>
        <div class="abttxt">
            <div>Embark on an extraordinary journey to the Lion City, Singapore, with EaseMyTrip! Get ready to be swept away by a whirlwind of awe-inspiring experiences. Delve into the dazzling world of futuristic wonders at Gardens by the Bay, where towering Supertrees and vibrant flora transport you to a mystical realm. Unleash your inner thrill-seeker at Sentosa Island with <a href="https://www.easemytrip.com/activities/activity-in-singapore/">activities in Singapore</a> and enjoy the adrenaline-pumping rides, pristine beaches, and jaw-dropping shows. Indulge in a tantalizing culinary escapade through the vibrant hawker centers, savoring the symphony of flavors that Singapore offers. Let EaseMyTrip be your guide as you unravel the secrets of this cosmopolitan gem, where adventure, culture, and endless surprises await!</div>
<div>&nbsp;</div>
<div id="inspect-element-top-layer" style="pointer-events: none; border: unset; padding: 0px;" data-inspect-element="inspectElement">&nbsp;</div>

        </div>
        <!-- ngIf: PackList.isFilter -->

        <div class="rightList">
            <style>
                .no-serch {
                    padding: 20px;
                    border: 1px solid #d6d6d6;
                    background: #fff;
                    width: 30%;
                    display: flex;
                    align-items: center;
                    flex-direction: column;
                    border-radius: 8px;
                    margin: 40px auto;
                    box-shadow: 0px 0px 8px 0px rgba(50,50,50,0.20);
                }

                .txtcnt {
                    margin-top: 15px;
                    font-weight: 600;
                }

                .ifslrTTC .inclsn, .inclsn .ifslrTTC, .ifslrTTC .inclsn {
                    display: none;
                }

                .ifslrTTC {
                    min-height: 340px;
                }

                    .ifslrTTC .pricesec {
                        padding: 0px;
                        display: none;
                    }
            </style>
            <div class="no-serch" id="no-serch-div" style="display:none">
                <img src="/holidays/Content/customize/img/no-content.png" width="80">
                <div class="txtcnt">No Package Available </div>
            </div>
            <div class="listpnl">
                
                <!-- ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638423908772645185/SightSeeing/SightSeeingOLewcq.jpg" src="https://media.easemytrip.com/media/Deal/DL638423908772645185/SightSeeing/SightSeeingOLewcq.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Fantastic Singapore</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 98990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638423908772645185">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 71990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638423908772645185" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../fantastic-singapore-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../fantastic-singapore-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">12755</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638557728239600523/SightSeeing/SightSeeingvrgk29.jpg" src="https://media.easemytrip.com/media/Deal/DL638557728239600523/SightSeeing/SightSeeingvrgk29.jpg"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Singapore Splendor with Genting Cruise</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Singapore | 2N Genting Dream Cruise</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 64499
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638557728239600523">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 54499
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638557728239600523" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../singapore-splendor-with-genting-cruise-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../singapore-splendor-with-genting-cruise-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">9840</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638572482386502917/SightSeeing/SightSeeinghBqIyK.png" src="https://media.easemytrip.com/media/Deal/DL638572482386502917/SightSeeing/SightSeeinghBqIyK.png"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Singapore Getaway</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">04 Nights Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 98990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638572482386502917">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 72490
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638572482386502917" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../singapore-getaway-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../singapore-getaway-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">12838</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638052309415788614/SightSeeing/SightSeeing4Hz5aw.jpg" src="https://media.easemytrip.com/media/Deal/DL638052309415788614/SightSeeing/SightSeeing4Hz5aw.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Explore Singapore with Royal Caribbean Cruise</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Singapore / 4N Cruise</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 69999
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638052309415788614">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 94999
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638052309415788614" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../explore-singapore-with-royal-caribbean-cruise-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../explore-singapore-with-royal-caribbean-cruise-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">16590</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638052330795740402/SightSeeing/SightSeeing3V5kBp.jpg" src="https://media.easemytrip.com/media/Deal/DL638052330795740402/SightSeeing/SightSeeing3V5kBp.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Amazing Singapore with Royal Caribbean Cruise</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Singapore | 3N Cruise</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 114990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638052330795740402">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 74990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638052330795740402" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../amazing-singapore-with-royal-caribbean-cruise-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../amazing-singapore-with-royal-caribbean-cruise-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">13255</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638053219887324093/SightSeeing/SightSeeingr5eXvv.jpg" src="https://media.easemytrip.com/media/Deal/DL638053219887324093/SightSeeing/SightSeeingr5eXvv.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Fabulous Singapore</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">04 Nights Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 49990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638053219887324093">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 42990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638053219887324093" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../fabulous-singapore-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../fabulous-singapore-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">7922</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638070477931061344/Attraction/AttractioneV0tV1.jpg" src="https://media.easemytrip.com/media/Deal/DL638070477931061344/Attraction/AttractioneV0tV1.jpg"></div>
                        
                        <p class="tnight ng-binding">3 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Singapore Vacay</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638070477931061344" type="radio" id="htl_01DL638070477931061344Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638070477931061344Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638070477931061344" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 47188
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹42250
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638070477931061344" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../singapore-vacay-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../singapore-vacay-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">8621</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638070533953597585/Attraction/Attractionlaa1f7.jpg" src="https://media.easemytrip.com/media/Deal/DL638070533953597585/Attraction/Attractionlaa1f7.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Best Singapore Holiday</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638070533953597585" type="radio" id="htl_01DL638070533953597585Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638070533953597585Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638070533953597585" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 68781
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹55056
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638070533953597585" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../best-singapore-holiday-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../best-singapore-holiday-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">12220</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638071369384462149/Attraction/AttractionbJBkKp.jpg" src="https://media.easemytrip.com/media/Deal/DL638071369384462149/Attraction/AttractionbJBkKp.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Dazzling Singapore</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">6N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638071369384462149" type="radio" id="htl_01DL638071369384462149Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638071369384462149Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638071369384462149" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 60612
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹70858
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638071369384462149" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../dazzling-singapore-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../dazzling-singapore-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">10859</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638071397555339166/Attraction/AttractionHen2LB.jpg" src="https://media.easemytrip.com/media/Deal/DL638071397555339166/Attraction/AttractionHen2LB.jpg"></div>
                        
                        <p class="tnight ng-binding">2 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Relaxing Singapore Getaway</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638071397555339166" type="radio" id="htl_01DL638071397555339166Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638071397555339166Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638071397555339166" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 43853
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹29522
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638071397555339166" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../relaxing-singapore-getaway-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../relaxing-singapore-getaway-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">8065</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638076616586571942/Island/IslandKSCa3S.jpg" src="https://media.easemytrip.com/media/Deal/DL638076616586571942/Island/IslandKSCa3S.jpg"></div>
                        
                        <p class="tnight ng-binding">10 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Singapore Thailand Special</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore | 3N Phuket | 3N Bangkok</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638076616586571942" type="radio" id="htl_01DL638076616586571942Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638076616586571942Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638076616586571942" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 94549
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹115163
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638076616586571942" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../singapore-thailand-special-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../singapore-thailand-special-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">16515</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638106764662598190/SightSeeing/SightSeeing0UvYzN.jpg" src="https://media.easemytrip.com/media/Deal/DL638106764662598190/SightSeeing/SightSeeing0UvYzN.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Spirited Singapore</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638106764662598190" type="radio" id="htl_01DL638106764662598190Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638106764662598190Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638106764662598190" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 96402
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹78455
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638106764662598190" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../spirited-singapore-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../spirited-singapore-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">16824</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638112957593572782/SightSeeing/SightSeeing02A8U5.jpg" src="https://media.easemytrip.com/media/Deal/DL638112957593572782/SightSeeing/SightSeeing02A8U5.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Thrilling Singapore</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638112957593572782" type="radio" id="htl_01DL638112957593572782Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638112957593572782Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638112957593572782" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 104618
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹85923
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638112957593572782" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../thrilling-singapore-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../thrilling-singapore-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">18398</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638112998318768343/SightSeeing/SightSeeingGInghs.jpg" src="https://media.easemytrip.com/media/Deal/DL638112998318768343/SightSeeing/SightSeeingGInghs.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Singapore Delights</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638112998318768343" type="radio" id="htl_01DL638112998318768343Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638112998318768343Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638112998318768343" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 66325
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹56145
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638112998318768343" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../singapore-delights-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../singapore-delights-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">11811</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638113044037007267/SightSeeing/SightSeeing04XAQB.jpg" src="https://media.easemytrip.com/media/Deal/DL638113044037007267/SightSeeing/SightSeeing04XAQB.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Adventour Singapore</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638113044037007267" type="radio" id="htl_01DL638113044037007267Premium" value="Premium" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638113044037007267Premium" class="ng-binding">
                                                        5
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638113044037007267" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 84454
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹96636
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638113044037007267" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../adventour-singapore-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../adventour-singapore-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">14832</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638116302510775676/SightSeeing/SightSeeinga7ryk2.jpg" src="https://media.easemytrip.com/media/Deal/DL638116302510775676/SightSeeing/SightSeeinga7ryk2.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Discover Singapore</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638116302510775676" type="radio" id="htl_01DL638116302510775676Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638116302510775676Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638116302510775676" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 85422
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹70127
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638116302510775676" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../discover-singapore-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../discover-singapore-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">14994</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638122359161397329/SightSeeing/SightSeeingpYBoss.jpg" src="https://media.easemytrip.com/media/Deal/DL638122359161397329/SightSeeing/SightSeeingpYBoss.jpg"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Singapore for Food Lovers</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">5N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn ng-hide" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638122359161397329" type="radio" id="htl_01DL638122359161397329Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638122359161397329Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638122359161397329" type="radio" id="htl_01DL638122359161397329Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638122359161397329Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638122359161397329" type="radio" id="htl_01DL638122359161397329Premium" value="Premium" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638122359161397329Premium" class="ng-binding">
                                                        5
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638122359161397329" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 103348
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹101906
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638122359161397329" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../singapore-for-food-lovers-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../singapore-for-food-lovers-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">18184</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638130980191093422/SightSeeing/SightSeeingvkpLL6.jpg" src="https://media.easemytrip.com/media/Deal/DL638130980191093422/SightSeeing/SightSeeingvkpLL6.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Singapore for Adventure Lovers</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638130980191093422" type="radio" id="htl_01DL638130980191093422Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638130980191093422Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638130980191093422" type="radio" id="htl_01DL638130980191093422Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638130980191093422Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638130980191093422" type="radio" id="htl_01DL638130980191093422Premium" value="Premium" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638130980191093422Premium" class="ng-binding">
                                                        5
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638130980191093422" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 71788
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹65619
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638130980191093422" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../singapore-for-adventure-lovers-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../singapore-for-adventure-lovers-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">12721</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638131065640117208/SightSeeing/SightSeeingkfguVl.jpg" src="https://media.easemytrip.com/media/Deal/DL638131065640117208/SightSeeing/SightSeeingkfguVl.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Singapore for Party Lovers</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638131065640117208" type="radio" id="htl_01DL638131065640117208Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638131065640117208Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638131065640117208" type="radio" id="htl_01DL638131065640117208Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638131065640117208Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638131065640117208" type="radio" id="htl_01DL638131065640117208Premium" value="Premium" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638131065640117208Premium" class="ng-binding">
                                                        5
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638131065640117208" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 83989
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹69269
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638131065640117208" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../singapore-for-party-lovers-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../singapore-for-party-lovers-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">14755</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638131079435980309/SightSeeing/SightSeeingiMOrWO.jpg" src="https://media.easemytrip.com/media/Deal/DL638131079435980309/SightSeeing/SightSeeingiMOrWO.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Singapore for Culture Lovers</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star ng-hide" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638131079435980309" type="radio" id="htl_01DL638131079435980309Standard" value="Standard" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638131079435980309Standard" class="ng-binding">
                                                        3
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638131079435980309" type="radio" id="htl_01DL638131079435980309Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638131079435980309Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638131079435980309" type="radio" id="htl_01DL638131079435980309Premium" value="Premium" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty">
                                                    <label for="htl_01DL638131079435980309Premium" class="ng-binding">
                                                        5
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd --><p class="strsbtxt ng-scope" ng-if="lst.isFlightAdd">Flight Included </p><!-- end ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd --><div class="tooltip-spacing ng-scope" ng-if="lst.isFlightAdd">
                                                    <div class="tooltip-text">?</div>
                                                </div><!-- end ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd --><div class="tooltiptext tooltip-bottom ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0 &amp;&amp; lst.isFlightAdd">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity">
                                                            <div class="plne_icn"><img src="https://www.easemytrip.com/holidays/Content/customize/img/Tooltip_Airplain.svg"></div>
                                                        </div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_prt tgl_selct ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <p class="incfl">Flight</p>
                                        <!-- ngIf: lst.flightAddRequest -->
                                        <!-- ngIf: !lst.flightAddRequest --><div class="toggle-btn ng-scope" ng-if="!lst.flightAddRequest">
                                            <label class="switch">
                                                <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                <span class="slider round"></span>
                                            </label>
                                        </div><!-- end ngIf: !lst.flightAddRequest -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 --><div class="tgle_bx ng-scope" ng-if="lst.IsAir  &amp;&amp; lst.isCustomize &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0">
                                        <!-- ngIf: lst.isFlightAdd --><div class="ttle_slc ng-scope" ng-if="lst.isFlightAdd">
                                            Including Flight
                                        </div><!-- end ngIf: lst.isFlightAdd -->
                                        <!-- ngIf: !lst.isFlightAdd -->
                                        <div class="tgle_qst">
                                            <div class="tgle_prt">
                                                <label class="switch">
                                                    <input type="checkbox" checked="" ng-model="lst.isFlightAdd" ng-change="ListFlightAddOn(lst,'true')" class="ng-pristine ng-untouched ng-valid ng-not-empty">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div class="tooltip">
                                                <div class="tooltip-spacing">
                                                    <div class="tooltip-bg1"></div>
                                                    <div class="tooltip-bg2"></div>
                                                    <div class="tooltip-text">?</div>
                                                </div>
                                                <div class="tooltiptext tooltip-bottom">
                                                    <div class="maincity mflex">
                                                        <div class="fromcity">
                                                            <div class="tyeu">From</div>
                                                            <div class="cityu ng-binding" ng-bind="lst.modeFMsg.from">DEL</div>
                                                        </div>
                                                        <div class="iconcity"><i class="aricon"></i></div>
                                                        <div class="tocityhu">
                                                            <div class="tiorig">To</div>
                                                            <div class="cityur ng-binding" ng-bind="lst.modeFMsg.to">SIN</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ngIf: lst.isFltRes -->
                                    </div><!-- end ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638131079435980309" style="display: block;">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 63138
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹54152
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638131079435980309" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize --><a ng-href="../singapore-for-culture-lovers-tours-package/" class="vdtl-btn ng-scope" ng-if="lst.isCustomize" href="../singapore-for-culture-lovers-tours-package/">Customize &amp; Book <img src="https://www.easemytrip.com/holidays/Content/customize/img/arrow-right.svg"></a><!-- end ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">11280</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638236305796995374/SightSeeing/SightSeeingdFW9eZ.jpg" src="https://media.easemytrip.com/media/Deal/DL638236305796995374/SightSeeing/SightSeeingdFW9eZ.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Explore Singapore with Family</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 75990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638236305796995374">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 68990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638236305796995374" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../explore-singapore-with-family-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../explore-singapore-with-family-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">12255</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638403141702316736/SightSeeing/SightSeeingc7B5tn.jpg" src="https://media.easemytrip.com/media/Deal/DL638403141702316736/SightSeeing/SightSeeingc7B5tn.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Fully Loaded Singapore with Sentosa Island</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore | 2N Sentosa Island</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 102990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638403141702316736">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 89990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638403141702316736" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../fully-loaded-singapore-with-sentosa-island-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../fully-loaded-singapore-with-sentosa-island-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">15755</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638404195203110040/SightSeeing/SightSeeing3C9F0Z.jpg" src="https://media.easemytrip.com/media/Deal/DL638404195203110040/SightSeeing/SightSeeing3C9F0Z.jpg"></div>
                        
                        <p class="tnight ng-binding">2 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Explore Sentosa</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">2N Sentosa</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 58990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638404195203110040">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 49990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638404195203110040" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../explore-sentosa-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../explore-sentosa-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">9088</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638404201259004818/SightSeeing/SightSeeingQ8Agis.jpg" src="https://media.easemytrip.com/media/Deal/DL638404201259004818/SightSeeing/SightSeeingQ8Agis.jpg"></div>
                        
                        <p class="tnight ng-binding">3 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Discover Sentosa 3 Nights</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Sentosa</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 69990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638404201259004818">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 53990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638404201259004818" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../discover-sentosa-3-nights-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../discover-sentosa-3-nights-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">9755</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638560375050998482/SightSeeing/SightSeeingsjuuTz.jpg" src="https://media.easemytrip.com/media/Deal/DL638560375050998482/SightSeeing/SightSeeingsjuuTz.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Spectacular Singapore</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 46990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638560375050998482">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 36990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638560375050998482" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../spectacular-singapore-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../spectacular-singapore-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">6922</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL637796638595732983/SightSeeing/SightSeeingWKRy08.jpg" src="https://media.easemytrip.com/media/Deal/DL637796638595732983/SightSeeing/SightSeeingWKRy08.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Best of Singapore</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 59999
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL637796638595732983">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 43999
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL637796638595732983" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../best-of-singapore-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../best-of-singapore-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">8090</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL637796655933954632/SightSeeing/SightSeeingJxzkMk.jpg" src="https://media.easemytrip.com/media/Deal/DL637796655933954632/SightSeeing/SightSeeingJxzkMk.jpg"></div>
                        
                        <p class="tnight ng-binding">3 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Supersaver Singapore</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">03 Nights Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 65990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL637796655933954632">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 49990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL637796655933954632" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../supersaver-singapore-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../supersaver-singapore-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">9088</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL637829356800355113/SightSeeing/SightSeeingaDpMJa.jpg" src="https://media.easemytrip.com/media/Deal/DL637829356800355113/SightSeeing/SightSeeingaDpMJa.jpg"></div>
                        
                        <p class="tnight ng-binding">4 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Singapore Explorer Fixed Departure</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">04 Nights Singapore</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 80890
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL637829356800355113">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 80890
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL637829356800355113" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../singapore-explorer-fixed-departure-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../singapore-explorer-fixed-departure-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">14238</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL637956616514362827/SightSeeing/SightSeeingAigHKJ.jpg" src="https://media.easemytrip.com/media/Deal/DL637956616514362827/SightSeeing/SightSeeingAigHKJ.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Pleasing Singapore and Bali</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Singapore | 3N Bali</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 63990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL637956616514362827">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 52990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL637956616514362827" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../pleasing-singapore-and-bali-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../pleasing-singapore-and-bali-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">9588</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL1905415342283-08AC2705-5647-43BA-8C4C-D75B62092D9F/SightSeeing/SightSeeingIMFKGD.jpg" src="https://media.easemytrip.com/media/Deal/DL1905415342283-08AC2705-5647-43BA-8C4C-D75B62092D9F/SightSeeing/SightSeeingIMFKGD.jpg"></div>
                        
                        <p class="tnight ng-binding">7 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Sojourn Singapore &amp; Malaysia</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">4N Singapore | 3N Kuala Lumpur</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 73990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL1905415342283-08AC2705-5647-43BA-8C4C-D75B62092D9F">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 63990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL1905415342283-08AC2705-5647-43BA-8C4C-D75B62092D9F" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../sojourn-singapore-and-malaysia-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../sojourn-singapore-and-malaysia-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">11422</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/14646/highlights-singapore-malaysia-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/14646/highlights-singapore-malaysia-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">13 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Highlights of Singapore and Malaysia</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Tour differently</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535195406121" type="radio" id="htl_01TTC638611535195406121Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535195406121Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535195406121">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 348451
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535195406121" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-highlights-of-singapore-and-malaysia-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-highlights-of-singapore-and-malaysia-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">59444</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  -->




            </div>
        </div>


    </div>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>
    </div>
      
</section>

<!-- packages section ends -->
      <!-- footer section starts  -->

<section class="footer">
   <div class="box-container">
      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>
      <div class="box">
         <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
      </div>
      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +880-1517-089144 </a>
         <a href="#"> <i class="fas fa-phone"></i> +111-2222-333333 </a>
         <a href="#"> <i class="fas fa-envelope"></i> vishalbca@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Raval, Devbhumi dwarka 361325  </a>
      </div>
      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
      </div>
   </div>
   <div class="credit"> designed by <span>mr. Vishal Vaghela</span> | all rights reserved! </div>
</section>

<!-- footer section ends -->
<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>