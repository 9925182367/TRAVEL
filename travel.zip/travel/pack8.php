<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Travel Agency :: Best Agency</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

   <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
   <script>
      $(document).ready(function(){
          $(".scroll-top").click(function() {
              $("html, body").animate({ 
                  scrollTop: 0 
              }, "slow");
              return false;
          });
      });
   </script>

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo"><img src="images/logo1.png"></a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php" class="active">package</a>
      <a href="book.php">book</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<div class="heading" style="background:url(images/header-bg-2.png) no-repeat">
   <h1>packages</h1>
</div>

<!-- packages section starts  -->

<section class="packages">

   <h1 class="heading-title">top destinations</h1>

   <div class="box-container">

   <div class="box">
         <div class="image">
            <img src="images/img-8.jpg" alt="">
         </div>
         <div class="content">
            <h3>canada Tour Packages</h3>
            <p>Enjoy the Emirates with unforgettable fun with our canada top selling packages!</p>
            <h2>BDT 21,900</h2>
            <div class="mid_wrap">
        <h2 class="headtl" style="text-transform: capitalize;">Canada Tour Packages</h2>
        <div class="abttxt">
            <p>Canada is a famous country which is situated in the northern part of North America and has many amazing cities. There are many points of interest in this country which makes it a perfect holiday destination and every year thousands of wanderlust travelers visit this marvelous place. Some of the outstanding places in Canada which magnetize tourists are Canada's Wonderland, Banff National Park, Niagara Falls, CN Tower, Notre-Dame Basilica, Old Montreal and Stanley Park etc. Canada holiday packages are in good demand; visit EaseMyTrip.com for the discounted deals and enjoy fun filled days in Canada.</p>
<div id="inspect-element-top-layer" style="pointer-events: none; border: unset; padding: 0px;" data-inspect-element="inspectElement">&nbsp;</div>

        </div>
        <!-- ngIf: PackList.isFilter -->

        <div class="rightList">
            <style>
                .no-serch {
                    padding: 20px;
                    border: 1px solid #d6d6d6;
                    background: #fff;
                    width: 30%;
                    display: flex;
                    align-items: center;
                    flex-direction: column;
                    border-radius: 8px;
                    margin: 40px auto;
                    box-shadow: 0px 0px 8px 0px rgba(50,50,50,0.20);
                }

                .txtcnt {
                    margin-top: 15px;
                    font-weight: 600;
                }

                .ifslrTTC .inclsn, .inclsn .ifslrTTC, .ifslrTTC .inclsn {
                    display: none;
                }

                .ifslrTTC {
                    min-height: 340px;
                }

                    .ifslrTTC .pricesec {
                        padding: 0px;
                        display: none;
                    }
            </style>
            <div class="no-serch" id="no-serch-div" style="display:none">
                <img src="/holidays/Content/customize/img/no-content.png" width="80">
                <div class="txtcnt">No Package Available </div>
            </div>
            <div class="listpnl">
                
                <!-- ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638460306602468050/Attraction/AttractionV8Z5gY.jpg" src="https://media.easemytrip.com/media/Deal/DL638460306602468050/Attraction/AttractionV8Z5gY.jpg"></div>
                        
                        <p class="tnight ng-binding">13 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Canadian Adventure Odyssey</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Vancouver | 1N Whistler-Sun peaks | 1N Jasper | 2N Banff | 1N Calgary | 2N Toronto | 1N Niagara Falls – Ottawa | 2N Montreal Quebec City</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 421990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638460306602468050">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 407990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638460306602468050" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../canadian-adventure-odyssey-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../canadian-adventure-odyssey-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">69466</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638460329995190944/Attraction/AttractionL32gRj.jpg" src="https://media.easemytrip.com/media/Deal/DL638460329995190944/Attraction/AttractionL32gRj.jpg"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Canadian Odyssey Discovery</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 164990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638460329995190944">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 154990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638460329995190944" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../canadian-odyssey-discovery-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../canadian-odyssey-discovery-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">26877</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638460910244134209/Attraction/AttractioniZFvOI.jpg" src="https://media.easemytrip.com/media/Deal/DL638460910244134209/Attraction/AttractioniZFvOI.jpg"></div>
                        
                        <p class="tnight ng-binding">8 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Wondrous Western Canada</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">03N Vancouver/01N Whistler - Sun peaks /01N Jasper/02N Banff/01N Calgary</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarDL638460910244134209" type="radio" id="htl_01DL638460910244134209Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01DL638460910244134209Deluxe" class="ng-binding">
                                                        4
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 258990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638460910244134209">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 258990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹258990
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638460910244134209" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../wondrous-western-canada-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../wondrous-western-canada-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">44384</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638460946203690514/SightSeeing/SightSeeingxai7GJ.jpg" src="https://media.easemytrip.com/media/Deal/DL638460946203690514/SightSeeing/SightSeeingxai7GJ.jpg"></div>
                        
                        <p class="tnight ng-binding">12 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Canadian Splendor Expedition</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Toronto | 3N Montreal | 3N Banff | 3N Vancouver</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 398990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638460946203690514">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 376990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638460946203690514" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../canadian-splendor-expedition-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../canadian-splendor-expedition-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">64248</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638460956972111923/SightSeeing/SightSeeingN5AjVV.jpg" src="https://media.easemytrip.com/media/Deal/DL638460956972111923/SightSeeing/SightSeeingN5AjVV.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Exquisite Eastern Canada</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N Toronto | 3N Montreal</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 198990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638460956972111923">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 168990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638460956972111923" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../exquisite-eastern-canada-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../exquisite-eastern-canada-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">29234</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638460972018036858/SightSeeing/SightSeeingQqPtJL.jpg" src="https://media.easemytrip.com/media/Deal/DL638460972018036858/SightSeeing/SightSeeingQqPtJL.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Canadian Rockies Adventure</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity">3N BANFF | 3N VANCOUVER</div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 248990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638460972018036858">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 212990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638460972018036858" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../canadian-rockies-adventure-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../canadian-rockies-adventure-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">36641</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638506722698345260/SightSeeing/SightSeeingfrrHdh.jpg" src="https://media.easemytrip.com/media/Deal/DL638506722698345260/SightSeeing/SightSeeingfrrHdh.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Splendid Canadian Tour: Toronto to Quebec</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 258990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638506722698345260">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 178990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638506722698345260" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../splendid-canadian-tour-toronto-to-quebec-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../splendid-canadian-tour-toronto-to-quebec-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">30917</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://media.easemytrip.com/media/Deal/DL638506806177382245/SightSeeing/SightSeeingxvovqG.jpg" src="https://media.easemytrip.com/media/Deal/DL638506806177382245/SightSeeing/SightSeeingxvovqG.jpg"></div>
                        
                        <p class="tnight ng-binding">6 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Canadian Wonders: A 7-Day Adventure</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn ng-hide" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding">
                                        ₹ 315990
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstDL638506806177382245">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 215990
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstDL638506806177382245" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../canadian-wonders-a-7-day-adventure-tours-package/" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../canadian-wonders-a-7-day-adventure-tours-package/">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">37146</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/fkvnnhf4/canada-snaps-03323-1.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/fkvnnhf4/canada-snaps-03323-1.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">18 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Ultimate Canada</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Social travel for 18-35 yrs ONLY</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535086506820" type="radio" id="htl_01TTC638611535086506820Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535086506820Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535086506820">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 344673
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535086506820" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-ultimate-canada-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-ultimate-canada-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">58808</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/bvzfymph/canada-snaps-03610-2.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/bvzfymph/canada-snaps-03610-2.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">10 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Canada and the Rockies</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Social travel for 18-35 yrs ONLY</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535095441535" type="radio" id="htl_01TTC638611535095441535Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535095441535Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535095441535">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 213017
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535095441535" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-canada-and-the-rockies-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-canada-and-the-rockies-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">36645</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/kbpkm1ke/contiki-_-usa-_-canada-_-atlantic-canada.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/kbpkm1ke/contiki-_-usa-_-canada-_-atlantic-canada.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">5 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Atlantic Canada</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Social travel for 18-35 yrs ONLY</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535096718673" type="radio" id="htl_01TTC638611535096718673Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535096718673Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535096718673">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 105711
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535096718673" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-atlantic-canada-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-atlantic-canada-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">18582</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/b0fp3jf0/gettyimages-996267946.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/b0fp3jf0/gettyimages-996267946.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">8 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Eastern Canada Adventure</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Social travel for 18-35 yrs ONLY</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535097519377" type="radio" id="htl_01TTC638611535097519377Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535097519377Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535097519377">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 133083
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535097519377" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-eastern-canada-adventure-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-eastern-canada-adventure-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">23189</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/6340/best-eastern-canada-usa-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/6340/best-eastern-canada-usa-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">15 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Best of Eastern Canada and USA</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Business class touring</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535132520169" type="radio" id="htl_01TTC638611535132520169Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535132520169Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535132520169">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 555045
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535132520169" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-best-of-eastern-canada-and-usa-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-best-of-eastern-canada-and-usa-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">94221</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/6342/canadian-rockies-pacific-coast-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/6342/canadian-rockies-pacific-coast-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">13 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Canadian Rockies and Pacific Coast</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Business class touring</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535133177089" type="radio" id="htl_01TTC638611535133177089Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535133177089Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535133177089">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 577253
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535133177089" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-canadian-rockies-and-pacific-coast-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-canadian-rockies-and-pacific-coast-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">97959</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/rafcvclo/eastern-canada-discovery-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/rafcvclo/eastern-canada-discovery-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">7 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Eastern Canada Discovery</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Business class touring</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535141272622" type="radio" id="htl_01TTC638611535141272622Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535141272622Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535141272622">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 255041
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535141272622" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-eastern-canada-discovery-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-eastern-canada-discovery-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">43719</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/3211/majesty-rockies-luxury-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/3211/majesty-rockies-luxury-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">8 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Majesty of the Rockies</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle"></div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535152518356" type="radio" id="htl_01TTC638611535152518356Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535152518356Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535152518356">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 829145
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535152518356" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-majesty-of-the-rockies-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-majesty-of-the-rockies-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">140362</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/14303/scenic-wonders-newfoundland-labrador-ile-saint-pierre-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/14303/scenic-wonders-newfoundland-labrador-ile-saint-pierre-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">11 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Scenic Wonders of Newfoundland and Labrador</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Tour differently</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535197947792" type="radio" id="htl_01TTC638611535197947792Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535197947792Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535197947792">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 319274
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535197947792" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-scenic-wonders-of-newfoundland-and-labrador-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-scenic-wonders-of-newfoundland-and-labrador-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">54532</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/14275/best-eastern-canada-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/14275/best-eastern-canada-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">8 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Best of Eastern Canada</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Tour differently</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535198417596" type="radio" id="htl_01TTC638611535198417596Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535198417596Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535198417596">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 258820
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535198417596" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-best-of-eastern-canada-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-best-of-eastern-canada-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">44355</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/14280/canadas-rockies-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/14280/canadas-rockies-guided-tour.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">7 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Canada's Rockies</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Tour differently</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535208817752" type="radio" id="htl_01TTC638611535208817752Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535208817752Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535208817752">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 260289
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535208817752" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-canada-s-rockies-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-canada-s-rockies-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">44603</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  --><div class="mainList ng-scope" ng-repeat="lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory} ">
                    
                    <div class="pos_cfc ng-hide" ng-show="lst.IsRecommended"><i class="edt1 po-ab"></i>  <span> <img src="https://www.easemytrip.com/images/icon_exc.svg">Recommended</span></div>

                    <div class="visearn ng-hide" ng-show="lst.isVistara != undefined &amp;&amp; lst.isVistara != null &amp;&amp; lst.isVistara">
                        <div class="visimg"><img src="https://www.easemytrip.com/images/advisory-img/club_vistara.png"></div>
                        <div class="visearnn ng-binding">
                            Earn  CV points
                        </div>
                    </div>
                    <div class="ListImg">
                        <div class="nigh-k5" style="text-transform: capitalize; display:none;"><span>Ex-</span><span ng-bind="exCity.CityName" class="ng-binding">new delhi</span></div>
                        <div ng-click="GoDetail(lst)"><img alt="" ng-src="https://content1.travcorpservices.com/media/10326/the-powder-rush-trip.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop" src="https://content1.travcorpservices.com/media/10326/the-powder-rush-trip.jpg?width=300&amp;amp;height=300&amp;amp;mode=crop"></div>
                        
                        <p class="tnight ng-binding">8 Nights</p>
                    </div>
                    <div class="listmid">
                        <div class="mflex">
                            <div class="pkgName ng-binding" ng-bind="lst.packageName">Ski Canada</div>

                        </div>
                        <div class="ctycvr ng-binding" ng-bind="lst.stayCity"></div>
						<div class="ctycvr ng-binding" ng-bind="lst.subTitle">Social travel for 18-35 yrs ONLY</div>
                        <div class="inclsn">

                            <div class="hicn" ng-show="lst.hotelStatus=='true'"><i class="i-htl"></i><span class="incTxt">Hotel</span></div>
                            <div class="hicn" ng-show="lst.sightStatus=='true'"><i class="i-sig"></i><span class="incTxt">Sightseeing</span></div>
                            <div class="hicn ng-hide" ng-show="lst.transferStatus=='true'"><i class="i-car"></i><span class="incTxt">Transfer</span></div>
                            <div class="hicn" ng-show="lst.mealStatus=='true'"><i class="i-mea"></i><span class="incTxt">Meal</span></div>
                            <div class="hicn ng-hide" ng-show="lst.flightStatus=='true' &amp;&amp; lst.packageType=='Package'"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            <div class="hicn ng-hide" ng-show="lst.visaStatus=='true'"><i class="i-visa"></i><span class="incTxt">Visa</span></div>
							<div class="hicn" ng-show="lst.busStatus=='true'"><i class="i-bus"></i><span class="incTxt">Bus</span></div>
                            
                            
                            <div class="hicn ng-hide" ng-show="lst.isFlightAdd &amp;&amp; lst.selectedOption.flights!=null &amp;&amp; lst.selectedOption.flights.length>0"><i class="i-fli"></i><span class="incTxt">Flight</span></div>
                            
                            <div class="hicn ng-hide" ng-show="lst.isCabAdd &amp;&amp; lst.selectedOption.cabs!=null &amp;&amp; lst.selectedOption.cabs.length>0"><i class="i-cab"></i><span class="incTxt">Cab</span></div>
                        </div>
                        <div class="htl_no_star" style="display:none;" ng-show="lst.packageType!='Dynamic'">
                            <p>Hotel Included story update you soon if star hotell not avoilabee</p>
                        </div>
                        <div class="htlstar ng-hide" ng-show="lst.packageType=='Dynamic'">
                            <div class="htlstar_50">
                                <p class="strsbtxt">Hotel Included</p>
                                <div class="mflex">
                                    <div class="stars-rating wd122">
                                        <ul>
                                            <!-- ngRepeat: opt in lst.options track by $index --><li ng-repeat="opt in lst.options track by $index" class="ng-scope">
                                                <span ng-click="UpdateListOption(opt,lst,$index)">
                                                    <input ng-model="opt.optionValue" name="hstarTTC638611535087520867" type="radio" id="htl_01TTC638611535087520867Deluxe" value="Deluxe" ng-checked="opt.option==lst.selectedOption.option" class="ng-pristine ng-untouched ng-valid ng-empty" checked="checked">
                                                    <label for="htl_01TTC638611535087520867Deluxe" class="ng-binding">
                                                        0
                                                        <span class="icon-star">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="9.078" height="8.673" viewBox="0 0 9.078 8.673">
                                                                <path id="Icon_feather-star" data-name="Icon feather-star" d="M7.139,3,8.418,5.591l2.86.418L9.209,8.025,9.7,10.873,7.139,9.527,4.581,10.873,5.07,8.025,3,6.009l2.86-.418Z" transform="translate(-2.6 -2.6)" fill="#707070" stroke="#707070" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"></path>
                                                            </svg>
                                                        </span>
                                                    </label>
                                                </span>
                                            </li><!-- end ngRepeat: opt in lst.options track by $index -->

                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="htlstar_50">
                                <div class="trns_ins">
                                    
                                    <!-- ngIf: lst.isFlightAdd -->
                                    <!-- ngIf: lst.isBusAdd -->
                                    <!-- ngIf: lst.isTrainAdd -->
                                    <div class="text">
                                        <div class="title">
                                            <div class="tooltip">
                                                <!-- ngIf: lst.isFlightAdd -->
                                                <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 && lst.isFlightAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 && lst.isBusAdd -->
                                                <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 && lst.isTrainAdd -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mglauto mflex flx_j_end">

                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isFltRes -->
                                    <div style="display:none;">
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                        <!-- ngIf: lst.isBusRes -->
                                        <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->

                                        <!-- ngIf: lst.isTrnRes -->
                                    </div>
                                </div>

                            </div>

                            <div class="mn_tgle" ng-init="AddOnToolSet(lst)" style="display:none;">
                                <div class="tgle_al">
                                    <!-- ngIf: lst.IsAir  && lst.isCustomize && lst.selectedOption.flights!=null && lst.selectedOption.flights.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.buses!=null && lst.selectedOption.buses.length>0 -->
                                    <!-- ngIf: lst.isCustomize && lst.selectedOption.trains!=null && lst.selectedOption.trains.length>0 -->
                                    <!-- ngIf: lst.isTrnRes -->
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="pricesec mflex acenter">
                        <div class="leftprc">

                            <div class="grd-ttl-prc">
                                <span class="sup_text">Starting from</span>
                                <span class="cutprice">
                                    <span ng-show="lst.selectedOption.twoPaxRackRate>0 &amp;&amp; lst.selectedOption.twoPaxRackRate > lst.selectedOption.twoPaxRate" class="ng-binding ng-hide">
                                        ₹ 0
                                    </span>
                                    
                                </span>
                                <span class="prc-ttl" id="showprlstTTC638611535087520867">
                                    <span ng-show="lst.selectedOption.twoPaxRate>0" class="ng-binding">
                                        ₹ 177081
                                    </span>
                                    <span ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0" class="ng-binding ng-hide">
                                        ₹0
                                    </span>
                                </span>
                                <div id="pricewaitlstTTC638611535087520867" style="display:none">
                                    <div class="stage"><div class="dot-pulse"></div></div>
                                </div>


                                <div class="clr"></div>
                                <span class="sub_text" ng-show="lst.selectedOption.twoPaxRate>0">Per Person on twin sharing</span>
                                <span class="sub_text ng-hide" ng-show="lst.selectedOption.twoPaxRate<1 &amp;&amp; lst.selectedOption.onePaxRate>0">Per Person on single occupancy</span>

                            </div>
                        </div>
                        <div class="ritbtn" ng-click="GoDetail(lst)">
                            <!-- ngIf: lst.isCustomize -->
                            <!-- ngIf: !lst.isCustomize --><a ng-href="../ttc-ski-canada-tours-package" class="vdtl-btn ng-scope" ng-if="!lst.isCustomize" href="../ttc-ski-canada-tours-package">View Package  </a><!-- end ngIf: !lst.isCustomize -->
                        </div>

                        <div class="clr"></div>
                        <div class="emi_text" id="emiotiondv" ng-show="lst.selectedOption.twoPaxRate>10000" ng-click="emiCalculator(lst.selectedOption.twoPaxRate)">
                            <img src="https://www.easemytrip.com/holidays/Content/customize/img/emi-pay-list.svg">No Cost EMI Starts from
                            &nbsp; <span class="ng-binding">
                                ₹ <span ng-bind="lst.minEmi" class="ng-binding">30596</span>   &nbsp; <a class="chsemi"> See option</a>
                            </span>
                            <div class="emibox" style="display:none;">
                                <ul>
                                    <!-- ngRepeat: tk in EmiLst -->

                                </ul>
                                <a class="emipy">Apply</a>
                            </div>

                        </div>
                    </div>

                </div><!-- end ngRepeat: lst in PackList.packageList|filter:filterfare |filter:filterduration |filter:{packageCotegory:packageCotegory}  -->




            </div>
        </div>


    </div>
            <a href="book.php" class="btn">book now</a>
         </div>
    </div>

      
</section>

<!-- packages section ends -->
      <!-- footer section starts  -->

<section class="footer">
   <div class="box-container">
      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>
      <div class="box">
         <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
      </div>
      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +880-1517-089144 </a>
         <a href="#"> <i class="fas fa-phone"></i> +111-2222-333333 </a>
         <a href="#"> <i class="fas fa-envelope"></i> vishalbca@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Raval, Devbhumi dwarka 361325  </a>
      </div>
      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
      </div>
   </div>
   <div class="credit"> designed by <span>mr. Vishal Vaghela</span> | all rights reserved! </div>
</section>

<!-- footer section ends -->
<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>